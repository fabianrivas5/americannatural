# De dónde viene cada efecto grabado

Todos son de dominio público (licencia CC0): se pueden usar, cambiar y publicar en videos comerciales sin pedir
permiso ni citar. Se recortaron, se pasaron a 48 kHz mono y algunos se ajustaron (más lentos, al revés, filtrados).

| Archivo | Origen |
|---|---|
| `whoosh-1.ogg` | «Swoosh 1» de D4XX, Freesound (https://freesound.org/people/D4XX/sounds/607252/), CC0 |
| `whoosh-2.ogg` | «Swoosh 2» de D4XX, Freesound (https://freesound.org/people/D4XX/sounds/607251/), CC0 |
| `whoosh-3.ogg` | «Swoosh 3» de D4XX, Freesound (https://freesound.org/people/D4XX/sounds/607250/), CC0 |
| `whoosh-largo-1.ogg` | «Long, Medium Swish.mp3» de deleted_user_6479820, Freesound (https://freesound.org/people/deleted_user_6479820/sounds/395019/), CC0 |
| `whoosh-largo-2.ogg` | «Whoosh - 150cm cardboard tube - OS Mono» de Sadiquecat, Freesound (https://freesound.org/people/Sadiquecat/sounds/855748/), CC0 |
| `whoosh-largo-3.ogg` | «Swoosh 3» de D4XX, Freesound (https://freesound.org/people/D4XX/sounds/607250/), CC0 |
| `swish-1.ogg` | «swoosh-1.mp3» de lesaucisson, Freesound (https://freesound.org/people/lesaucisson/sounds/585257/), CC0 |
| `swish-2.ogg` | «Swoosh 1» de D4XX, Freesound (https://freesound.org/people/D4XX/sounds/607252/), CC0 |
| `subida-1.ogg` | «Riser sound effect short.wav» de syntheffects, Freesound (https://freesound.org/people/syntheffects/sounds/685256/), CC0 |
| `bajada-1.ogg` | «Riser sound effect short.wav» de syntheffects, Freesound (https://freesound.org/people/syntheffects/sounds/685256/), CC0 |
| `golpe-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-suave-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-suave-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-suave-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-seco-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-seco-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `golpe-seco-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `impacto-1.ogg` | «Sound Design Elements Impact SFX PS 020» de AudioPapkin, Freesound (https://freesound.org/people/AudioPapkin/sounds/755057/), CC0 |
| `impacto-2.ogg` | «Impact sfx 027.wav» de AudioPapkin, Freesound (https://freesound.org/people/AudioPapkin/sounds/645898/), CC0 |
| `roca-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `roca-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `roca-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `madera-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `madera-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `madera-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `metal-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `metal-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `metal-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `cristal-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `cristal-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `cristal-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `boom-1.ogg` | «large explosion 1» de V-ktor, Freesound (https://freesound.org/people/V-ktor/sounds/482993/), CC0 |
| `boom-2.ogg` | «explosion.wav» de IdkMrGarcia, Freesound (https://freesound.org/people/IdkMrGarcia/sounds/446625/), CC0 |
| `estallido-1.ogg` | Kenney, «sci fi sounds» (kenney.nl), CC0 |
| `estallido-2.ogg` | Kenney, «sci fi sounds» (kenney.nl), CC0 |
| `estallido-3.ogg` | Kenney, «sci fi sounds» (kenney.nl), CC0 |
| `clic-1.ogg` | Kenney, «ui audio» (kenney.nl), CC0 |
| `clic-2.ogg` | Kenney, «ui audio» (kenney.nl), CC0 |
| `clic-3.ogg` | Kenney, «ui audio» (kenney.nl), CC0 |
| `tic-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `tic-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `tic-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `pop-1.ogg` | «Pop sound» de deraj, Freesound (https://freesound.org/people/deraj/sounds/202230/), CC0 |
| `pop-2.ogg` | «Pop 4» de quatricise, Freesound (https://freesound.org/people/quatricise/sounds/789793/), CC0 |
| `burbuja-1.ogg` | «Bubbles_Single2.wav» de BMacZero, Freesound (https://freesound.org/people/BMacZero/sounds/96125/), CC0 |
| `burbuja-2.ogg` | «Bubbles_Single3.wav» de BMacZero, Freesound (https://freesound.org/people/BMacZero/sounds/96126/), CC0 |
| `gota-1.ogg` | «Single Water Drop» de paespedro, Freesound (https://freesound.org/people/paespedro/sounds/174718/), CC0 |
| `gota-2.ogg` | «water drop 1.aif» de beskhu, Freesound (https://freesound.org/people/beskhu/sounds/273870/), CC0 |
| `camara-1.ogg` | «camera shutter.wav» de mywhats, Freesound (https://freesound.org/people/mywhats/sounds/175517/), CC0 |
| `papel-1.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `papel-2.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `tela-1.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `tela-2.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `monedas-1.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `paso-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `paso-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `paso-3.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `brillo-1.ogg` | «cartoon_wink_magic_sparkle.wav» de MLaudio, Freesound (https://freesound.org/people/MLaudio/sounds/511485/), CC0 |
| `acierto-1.ogg` | Kenney, «interface sounds» (kenney.nl), CC0 |
| `acierto-2.ogg` | Kenney, «interface sounds» (kenney.nl), CC0 |
| `error-1.ogg` | Kenney, «interface sounds» (kenney.nl), CC0 |
| `error-2.ogg` | Kenney, «interface sounds» (kenney.nl), CC0 |
| `aviso-1.ogg` | «Pop-up/notification.wav» de GabrielAraujo, Freesound (https://freesound.org/people/GabrielAraujo/sounds/242502/), CC0 |
| `tecleo-1.ogg` | «Keyboard typing» de Breviceps, Freesound (https://freesound.org/people/Breviceps/sounds/447909/), CC0 |
| `latido-1.ogg` | «Single Heartbeat Clean HQ_BeatSmith.wav» de Lunardrive, Freesound (https://freesound.org/people/Lunardrive/sounds/22440/), CC0 |
| `burbujas-1.ogg` | «Bubbles 004.wav» de ristooooo1, Freesound (https://freesound.org/people/ristooooo1/sounds/539819/), CC0 |
| `salpicadura-1.ogg` | «Big Water Splash» de qubodup, Freesound (https://freesound.org/people/qubodup/sounds/442773/), CC0 |
| `salpicadura-2.ogg` | «Splash-eau-goudron1.wav» de rombart, Freesound (https://freesound.org/people/rombart/sounds/186748/), CC0 |
| `hielo-1.ogg` | «Ice Crack 1» de j_p_higgins, Freesound (https://freesound.org/people/j_p_higgins/sounds/262635/), CC0 |
| `chispa-1.ogg` | «Electric zap.wav» de michael_grinnell, Freesound (https://freesound.org/people/michael_grinnell/sounds/512471/), CC0 |
| `laser-1.ogg` | Kenney, «sci fi sounds» (kenney.nl), CC0 |
| `laser-2.ogg` | Kenney, «sci fi sounds» (kenney.nl), CC0 |
| `ambiente-agua-1.ogg` | «Underwater Beneath Waterfall or Rain (Loopable).wav» de Osiruswaltz, Freesound (https://freesound.org/people/Osiruswaltz/sounds/530167/), CC0 |
| `viento-1.ogg` | «wind3.wav» de eliasheuninck, Freesound (https://freesound.org/people/eliasheuninck/sounds/29532/), CC0 |
| `calle-1.ogg` | «Seamless City Loop» de qubodup, Freesound (https://freesound.org/people/qubodup/sounds/223093/), CC0 |
| `embestida-1.ogg` | «woosh.wav» de freakinbehemoth, Freesound (https://freesound.org/people/freakinbehemoth/sounds/243400/), CC0 + Kenney, «impact sounds» (kenney.nl), CC0 |
| `embestida-2.ogg` | «Long, Medium Swish.mp3» de deleted_user_6479820, Freesound (https://freesound.org/people/deleted_user_6479820/sounds/395019/), CC0 + Kenney, «impact sounds» (kenney.nl), CC0 |
| `sube-1.ogg` | «Swoosh 1» de D4XX, Freesound (https://freesound.org/people/D4XX/sounds/607252/), CC0 |
| `sube-2.ogg` | «Swoosh 2» de D4XX, Freesound (https://freesound.org/people/D4XX/sounds/607251/), CC0 |
| `deslizar-1.ogg` | «Metal Slide 2» de LordForklift, Freesound (https://freesound.org/people/LordForklift/sounds/448418/), CC0 |
| `deslizar-2.ogg` | «Metal Slide 2» de WasabiWielder, Freesound (https://freesound.org/people/WasabiWielder/sounds/323369/), CC0 |
| `golpe-grave-1.ogg` | «Thud.wav» de Bird_man, Freesound (https://freesound.org/people/Bird_man/sounds/275160/), CC0 |
| `golpe-grave-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 |
| `bloque-1.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 + «Thud.wav» de Bird_man, Freesound (https://freesound.org/people/Bird_man/sounds/275160/), CC0 |
| `bloque-2.ogg` | Kenney, «impact sounds» (kenney.nl), CC0 + «Thud.wav» de Bird_man, Freesound (https://freesound.org/people/Bird_man/sounds/275160/), CC0 |
| `canonazo-1.ogg` | «Retro, Pirate Cannon Shot» de LilMati, Freesound (https://freesound.org/people/LilMati/sounds/515801/), CC0 |
| `canonazo-2.ogg` | «Explosion.wav» de Bird_man, Freesound (https://freesound.org/people/Bird_man/sounds/275155/), CC0 |
| `aterrizaje-1.ogg` | «Human Impact on Ground» de alegemaate, Freesound (https://freesound.org/people/alegemaate/sounds/364690/), CC0 |
| `aterrizaje-2.ogg` | «Landing On The Ground [6]» de SoundDesignForYou, Freesound (https://freesound.org/people/SoundDesignForYou/sounds/646663/), CC0 |
| `madera-rota-1.ogg` | «Crate Break 4.wav» de kevinkace, Freesound (https://freesound.org/people/kevinkace/sounds/66780/), CC0 |
| `madera-rota-2.ogg` | «Barrel Break 4.wav» de kevinkace, Freesound (https://freesound.org/people/kevinkace/sounds/66772/), CC0 |
| `hueco-1.ogg` | «hit - metallic - deep hollow thunk.wav» de Anthousai, Freesound (https://freesound.org/people/Anthousai/sounds/406493/), CC0 |
| `hueco-2.ogg` | «Clang» de qubodup, Freesound (https://freesound.org/people/qubodup/sounds/812592/), CC0 |
| `lingotes-1.ogg` | «Iron Bar Drop onto Wood & Straw Floor» de dkudos, Freesound (https://freesound.org/people/dkudos/sounds/213124/), CC0 |
| `lingotes-2.ogg` | «Loud Bang Crashing Metal Chunk Dropped in Metal Dumpster» de qubodup, Freesound (https://freesound.org/people/qubodup/sounds/859154/), CC0 |
| `crujido-1.ogg` | «Crushing aluminum can 2.wav» de nahmandub, Freesound (https://freesound.org/people/nahmandub/sounds/131323/), CC0 |
| `crujido-2.ogg` | «Crushed Can.wav» de husky70, Freesound (https://freesound.org/people/husky70/sounds/157300/), CC0 |
| `enganche-1.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `enganche-2.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `toque-1.ogg` | «Glass Tap 2» de CJspellsfish, Freesound (https://freesound.org/people/CJspellsfish/sounds/668383/), CC0 |
| `toque-2.ogg` | «Fingers nails on glass bottle - tap.wav» de ValentinPetiteau, Freesound (https://freesound.org/people/ValentinPetiteau/sounds/610392/), CC0 |
| `aplastar-1.ogg` | «Tomato squish;wet.wav» de HonorHunter, Freesound (https://freesound.org/people/HonorHunter/sounds/271666/), CC0 |
| `aplastar-2.ogg` | «Gooey Squish» de editor_adp, Freesound (https://freesound.org/people/editor_adp/sounds/269482/), CC0 |
| `rebote-1.ogg` | «Plastic Bouncing Ball.wav» de Uzbazur, Freesound (https://freesound.org/people/Uzbazur/sounds/329684/), CC0 |
| `rebote-2.ogg` | «Ping pong ball hit» de michorvath, Freesound (https://freesound.org/people/michorvath/sounds/269718/), CC0 |
| `timbre-1.ogg` | «Bike Bell.wav» de bsumusictech, Freesound (https://freesound.org/people/bsumusictech/sounds/81875/), CC0 |
| `timbre-2.ogg` | «bicycle bell.wav» de marcolo91, Freesound (https://freesound.org/people/marcolo91/sounds/156064/), CC0 |
| `cristal-roto-1.ogg` | «Glass Break» de avrahamy, Freesound (https://freesound.org/people/avrahamy/sounds/141563/), CC0 |
| `cristal-roto-2.ogg` | «Breaking-Glass.wav» de wjl, Freesound (https://freesound.org/people/wjl/sounds/267889/), CC0 |
| `trueno-1.ogg` | «thunder1.wav» de nednednerb, Freesound (https://freesound.org/people/nednednerb/sounds/38244/), CC0 |
| `trueno-2.ogg` | «Distant Thunder 3» de Fission9, Freesound (https://freesound.org/people/Fission9/sounds/581124/), CC0 |
| `aplausos-1.ogg` | «APPLAUSE.WAV» de erkanozan, Freesound (https://freesound.org/people/erkanozan/sounds/51743/), CC0 |
| `aplausos-2.ogg` | «Crowd.Yay.Applause.25ppl.Short.wav» de jessepash, Freesound (https://freesound.org/people/jessepash/sounds/139972/), CC0 |
| `cremallera-1.ogg` | «Zipper Unzip 3 (Slow) .wav» de RutgerMuller, Freesound (https://freesound.org/people/RutgerMuller/sounds/51176/), CC0 |
| `cremallera-2.ogg` | «zipper5.wav» de florian_reinke, Freesound (https://freesound.org/people/florian_reinke/sounds/63519/), CC0 |
| `coche-1.ogg` | «Car passing by.wav» de hinzebeat, Freesound (https://freesound.org/people/hinzebeat/sounds/171447/), CC0 |
| `coche-2.ogg` | «Passing Car (Wet road)» de Breviceps, Freesound (https://freesound.org/people/Breviceps/sounds/462862/), CC0 |
| `verter-1.ogg` | «pouring water 2015.wav» de bart1234567, Freesound (https://freesound.org/people/bart1234567/sounds/319963/), CC0 |
| `verter-2.ogg` | «pouring with two drips at the end» de Mafon2, Freesound (https://freesound.org/people/Mafon2/sounds/330025/), CC0 |
| `caja-1.ogg` | «Cash Register Purchase» de Zott820, Freesound (https://freesound.org/people/Zott820/sounds/209578/), CC0 |
| `caja-2.ogg` | «Cash Register Fake.wav» de CapsLok, Freesound (https://freesound.org/people/CapsLok/sounds/184438/), CC0 |
| `vibracion-1.ogg` | «Phone vibration» de Breviceps, Freesound (https://freesound.org/people/Breviceps/sounds/515295/), CC0 |
| `vibracion-2.ogg` | «phone short buzz» de richwise, Freesound (https://freesound.org/people/richwise/sounds/476836/), CC0 |
| `lapiz-1.ogg` | «Pencil Writing on Paper» de elliotlp, Freesound (https://freesound.org/people/elliotlp/sounds/277312/), CC0 |
| `lapiz-2.ogg` | «Pencil2.wav» de stijn, Freesound (https://freesound.org/people/stijn/sounds/43674/), CC0 |
| `efervescencia-1.ogg` | «Soda Pour» de pillwave, Freesound (https://freesound.org/people/pillwave/sounds/436008/), CC0 |
| `corcho-1.ogg` | «bottlepop44.wav» de ahill86, Freesound (https://freesound.org/people/ahill86/sounds/206152/), CC0 |
| `glitch-1.ogg` | «Glitch 01» de JacksonMiller0, Freesound (https://freesound.org/people/JacksonMiller0/sounds/237607/), CC0 |
| `glitch-2.ogg` | «Digital Glitch_v1.wav» de tadaizm, Freesound (https://freesound.org/people/tadaizm/sounds/458065/), CC0 |
| `glitch-3.ogg` | «glitched sound 1.wav» de Elnosos, Freesound (https://freesound.org/people/Elnosos/sounds/424375/), CC0 |
| `puerta-1.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `puerta-2.ogg` | Kenney, «rpg audio» (kenney.nl), CC0 |
| `computadora-1.ogg` | Kenney, «sci fi sounds» (kenney.nl), CC0 |
| `computadora-2.ogg` | Kenney, «sci fi sounds» (kenney.nl), CC0 |
| `lluvia-1.ogg` | «Light Rain» de soundrecorder7, Freesound (https://freesound.org/people/soundrecorder7/sounds/167034/), CC0 |
| `mar-1.ogg` | «Ocean Waves Sounds Of The Foam.wav» de davidgtr1, Freesound (https://freesound.org/people/davidgtr1/sounds/581487/), CC0 |
| `fuego-1.ogg` | «Fire Crackling 01.wav» de kingsrow, Freesound (https://freesound.org/people/kingsrow/sounds/181563/), CC0 |
| `bosque-1.ogg` | «Ambiance_Natural_Forest_Birds_Wind_Loop_Stereo.wav» de Nox_Sound, Freesound (https://freesound.org/people/Nox_Sound/sounds/570492/), CC0 |
| `reloj-1.ogg` | «Clock Ticks (Loopable!)» de se2001, Freesound (https://freesound.org/people/se2001/sounds/511967/), CC0 |
| `hervir-1.ogg` | «37 - 17 Boiling water.wav» de 14FPanska_Nemec_Petr, Freesound (https://freesound.org/people/14FPanska_Nemec_Petr/sounds/420228/), CC0 |
