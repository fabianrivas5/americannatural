# Contornos de la Tierra

`tierra.json` son los contornos de la tierra firme, del hielo de Groenlandia y las islas árticas, y las 220 ciudades más
grandes, sacados de **Natural Earth** (https://www.naturalearthdata.com), que es de dominio público: se puede usar para
cualquier cosa, también comercial, sin pedir permiso ni citar.

Se simplificaron para dibujarlos rápido (escala 1:50 millones, puntos cada décima de grado como mucho, sin islas de
menos de un cuarto de grado cuadrado). El globo (`engine/draw/globe.mjs`) los dibuja como formas: no hay fotos.
