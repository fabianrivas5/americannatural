#!/usr/bin/env bash
# Reproduce la prueba completa: voz (prevista o real) → plan de audio/subtítulos → mezcla, para las aperturas A y B.
# Uso: bash correr_prueba.sh <carpeta_de_trabajo>      (con voz real: pon voz/apertura_A.wav+.json, etc. y exporta VOZ_REAL=1)
set -euo pipefail
SKILL="$(cd "$(dirname "$0")/../.." && pwd)"; S="$SKILL/scripts"
W="${1:-./video_american_fit}"; mkdir -p "$W"; cd "$W"
cp "$SKILL/ejemplos/american_fit/storyboard.json" .
python3 - <<'PY'
import json; sb = json.load(open("storyboard.json"))
for k, v in sb["aperturas"].items():
    open(f"apertura_{k}.txt", "w").write(" ".join(e["voz"] for e in v["escenas"]))
open("cuerpo.txt", "w").write(" ".join(e["voz"] for e in sb["cuerpo"]))
PY
if [ "${VOZ_REAL:-0}" != "1" ]; then
  # 2,65 palabras/s = ritmo medido en la toma real de ElevenLabs de la apertura A (9 palabras en 3,39 s)
  for s in apertura_A apertura_B cuerpo; do python3 "$S/voz.py" estimar --texto-archivo "$s.txt" --pps 2.65 --salida "voz/$s"; done
fi
python3 "$S/voz.py" comparar voz/apertura_A voz/apertura_B || echo "→ ajusta una apertura: no son comparables"
for v in A B; do
  python3 "$S/voz.py" ensamblar --segmentos "voz/apertura_$v" voz/cuerpo --pausa 0.25 --salida "voz/variante_$v"
  python3 "$S/plan_audio.py" --storyboard storyboard.json --apertura "$v" --palabras "voz/variante_$v.json" --salida "build_$v"
  python3 "$S/mezclar.py" --timeline "build_$v/timeline.json" --voz "voz/variante_$v.wav" --salida "build_$v/mezcla.wav"
done
