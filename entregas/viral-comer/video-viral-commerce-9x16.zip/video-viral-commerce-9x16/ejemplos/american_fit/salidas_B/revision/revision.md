# Revisión · video_final_9x16_B.mp4 · apertura B

> **Tiempos PREVISTOS**: la voz no es la definitiva. Repetir esta revisión con la voz real.

## Técnica (automático)

| Control | Medido | Resultado |
|---|---|---|
| Resolución 1080×1920 | 1080×1920 | ✔ |
| 30 fps | 30.000 | ✔ |
| H.264 yuv420p | h264 yuv420p | ✔ |
| Audio AAC | aac | ✔ |
| faststart (moov al inicio) | sí | ✔ |
| Duración = voz ±0,1 s | 41.964 vs 41.964 | ✔ |
| Sin tramos estáticos > 2 s | ninguno | ✔ |
| Peso razonable (≤ 8 Mb/s) | 25.6 MB · 4.9 Mb/s | ✔ |
| Sonoridad −14 ±1 LUFS | -26.2 LUFS · NO APLICA: vista previa sin voz real | ✔ |
| Pico real ≤ −1 dBTP | -6.0 dBTP | ✔ |

## Fotogramas en palabra clave (zona segura en rojo) — `hoja_contacto.jpg`

| Segundo | Se oye | Debe verse | Efecto | Fotograma | Defecto | Corrección | Estado |
|---|---|---|---|---|---|---|---|
| 03,399 | «esto» — Si llevas días sin ir al baño, mira esto. | calendario pasa tres hojas; zoom que entra al abdomen | whoosh-largo-1.ogg | `fotogramas/B1_003.40s.jpg` | | | pendiente de mirar |
| 08,820 | «atrapado» — Cuando tu intestino va lento, lo que comes se queda atrapado. | corte transversal del intestino; bolitas de comida avanzan y se frenan | golpe-suave-1.ogg | `fotogramas/C1_008.82s.jpg` | | | pendiente de mirar |
| 13,948 | «cierra» — Se acumulan gases, te sientes pesado y el pantalón ya no cierra. | burbujas de gas suben; pesa aparece; botón del pantalón no cierra | enganche-1.ogg | `fotogramas/C2_013.95s.jpg` | | | pendiente de mirar |
| 15,837 | «falta» — ¿Entonces qué le falta a tu intestino? | signo de pregunta grande sobre el tubo | — | `fotogramas/C3_015.84s.jpg` | | | pendiente de mirar |
| 21,343 | «empujón» — Necesita dos cosas: fibra para tu flora y un empujón. | pantalla dividida: hoja de fibra / flecha que empuja | deslizar-2.ogg | `fotogramas/C4_021.34s.jpg` | | | pendiente de mirar |
| 23,232 | «American Fit» — Por eso existe American Fit, de American Natural. | el frasco real entra desde abajo con rebote leve | golpe-seco-1.ogg | `fotogramas/C5_023.23s.jpg` | | | pendiente de mirar |
| 26,097 | «sen» — Trae sen, fibra prebiótica, magnesio, vitamina C y té matcha. | cinco etiquetas salen del frasco una por una | clic-1.ogg | `fotogramas/C6_026.10s.jpg` | | | pendiente de mirar |
| 32,640 | «aluminio» — Sesenta cápsulas, en frasco de aluminio con su marca. | contador 0→60; macro del frasco con la marca | metal-2.ogg | `fotogramas/C7_032.64s.jpg` | | | pendiente de mirar |
| 35,661 | «pagas» — Pídelo hoy y pagas cuando lo recibes en tu casa. | caja llega a una puerta; texto 'Pagas al recibir' | — | `fotogramas/C8_035.66s.jpg` | | | pendiente de mirar |
| 39,437 | «WhatsApp» — Escríbenos por WhatsApp y separa el tuyo. | la misma silueta del gancho con el celular; burbuja de chat | pop-2.ogg | `fotogramas/C9_039.44s.jpg` | | | pendiente de mirar |

Mirar en cada fotograma: imagen = palabra en ese instante (≤ 2 fotogramas), sujeto legible en móvil, continuidad de frasco/luz/color, nada cortado ni bajo botones o descripción, subtítulo sin tapar sujeto/etiqueta, pico del efecto en el gesto.

## Escucha (manual)

- [ ] voz + efectos juntos, sin saturación ni desfase
- [ ] palabra clave y CTA claros en `mezcla_mono.wav`
- [ ] CTA claro en `mezcla_telefono.wav` (altavoz de teléfono)
- [ ] ninguna pista termina de golpe
