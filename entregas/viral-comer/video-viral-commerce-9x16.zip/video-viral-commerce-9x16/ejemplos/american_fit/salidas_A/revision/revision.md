# Revisión · video_final_9x16_A.mp4 · apertura A

> **Tiempos PREVISTOS**: la voz no es la definitiva. Repetir esta revisión con la voz real.

## Técnica (automático)

| Control | Medido | Resultado |
|---|---|---|
| Resolución 1080×1920 | 1080×1920 | ✔ |
| 30 fps | 30.000 | ✔ |
| H.264 yuv420p | h264 yuv420p | ✔ |
| Audio AAC | aac | ✔ |
| faststart (moov al inicio) | sí | ✔ |
| Duración = voz ±0,1 s | 41.733 vs 41.744 | ✔ |
| Sin tramos estáticos > 2 s | ninguno | ✔ |
| Peso razonable (≤ 8 Mb/s) | 25.1 MB · 4.8 Mb/s | ✔ |
| Sonoridad −14 ±1 LUFS | -26.0 LUFS · NO APLICA: vista previa sin voz real | ✔ |
| Pico real ≤ −1 dBTP | -6.0 dBTP | ✔ |

## Fotogramas en palabra clave (zona segura en rojo) — `hoja_contacto.jpg`

| Segundo | Se oye | Debe verse | Efecto | Fotograma | Defecto | Corrección | Estado |
|---|---|---|---|---|---|---|---|
| 03,179 | «inflada» — ¿Comes poco y aun así tu barriga amanece inflada? | plato casi vacío; la barriga de la silueta se infla | sube-1.ogg | `fotogramas/A1_003.18s.jpg` | | | pendiente de mirar |
| 08,600 | «atrapado» — Cuando tu intestino va lento, lo que comes se queda atrapado. | corte transversal del intestino; bolitas de comida avanzan y se frenan | golpe-suave-1.ogg | `fotogramas/C1_008.60s.jpg` | | | pendiente de mirar |
| 13,728 | «cierra» — Se acumulan gases, te sientes pesado y el pantalón ya no cierra. | burbujas de gas suben; pesa aparece; botón del pantalón no cierra | enganche-1.ogg | `fotogramas/C2_013.73s.jpg` | | | pendiente de mirar |
| 15,617 | «falta» — ¿Entonces qué le falta a tu intestino? | signo de pregunta grande sobre el tubo | — | `fotogramas/C3_015.62s.jpg` | | | pendiente de mirar |
| 21,123 | «empujón» — Necesita dos cosas: fibra para tu flora y un empujón. | pantalla dividida: hoja de fibra / flecha que empuja | deslizar-2.ogg | `fotogramas/C4_021.12s.jpg` | | | pendiente de mirar |
| 23,012 | «American Fit» — Por eso existe American Fit, de American Natural. | el frasco real entra desde abajo con rebote leve | golpe-seco-1.ogg | `fotogramas/C5_023.01s.jpg` | | | pendiente de mirar |
| 25,877 | «sen» — Trae sen, fibra prebiótica, magnesio, vitamina C y té matcha. | cinco etiquetas salen del frasco una por una | clic-1.ogg | `fotogramas/C6_025.88s.jpg` | | | pendiente de mirar |
| 32,420 | «aluminio» — Sesenta cápsulas, en frasco de aluminio con su marca. | contador 0→60; macro del frasco con la marca | metal-2.ogg | `fotogramas/C7_032.42s.jpg` | | | pendiente de mirar |
| 35,441 | «pagas» — Pídelo hoy y pagas cuando lo recibes en tu casa. | caja llega a una puerta; texto 'Pagas al recibir' | — | `fotogramas/C8_035.44s.jpg` | | | pendiente de mirar |
| 39,217 | «WhatsApp» — Escríbenos por WhatsApp y separa el tuyo. | la misma silueta del gancho con el celular; burbuja de chat | pop-2.ogg | `fotogramas/C9_039.22s.jpg` | | | pendiente de mirar |

Mirar en cada fotograma: imagen = palabra en ese instante (≤ 2 fotogramas), sujeto legible en móvil, continuidad de frasco/luz/color, nada cortado ni bajo botones o descripción, subtítulo sin tapar sujeto/etiqueta, pico del efecto en el gesto.

## Escucha (manual)

- [ ] voz + efectos juntos, sin saturación ni desfase
- [ ] palabra clave y CTA claros en `mezcla_mono.wav`
- [ ] CTA claro en `mezcla_telefono.wav` (altavoz de teléfono)
- [ ] ninguna pista termina de golpe
