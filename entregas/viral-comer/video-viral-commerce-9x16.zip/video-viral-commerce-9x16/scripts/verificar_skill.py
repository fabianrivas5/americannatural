#!/usr/bin/env python3
"""Comprueba que el paquete de la skill está completo: rutas citadas en SKILL.md/referencias/plantillas existen,
los scripts compilan, el banco de sonidos coincide con su catálogo y las huellas SHA-256 cuadran.

  python3 verificar_skill.py
"""
import re
import subprocess
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
RAICES = ("recursos/", "scripts/", "plantillas/", "referencias/", "ejemplos/")


def main():
    fallos = 0
    docs = [SKILL / "SKILL.md", *sorted((SKILL / "referencias").glob("*.md")), *sorted((SKILL / "plantillas").glob("*.md"))]
    citas = set()
    for d in docs:
        for m in re.finditer(r"(?:<skill>/)?((?:recursos|scripts|plantillas|referencias|ejemplos)/[\w./\-áéíóúñ]+)", d.read_text(encoding="utf-8")):
            ruta = m.group(1).rstrip(".,)")
            if ruta.startswith(RAICES):
                citas.add(ruta)
    for r in sorted(citas):
        if not (SKILL / r).exists():
            fallos += 1; print("✘ ruta citada no existe:", r)
    print(f"Rutas citadas: {len(citas) - fallos}/{len(citas)} existen")
    for py in sorted((SKILL / "scripts").glob("*.py")):
        try:
            compile(py.read_text(encoding="utf-8"), str(py), "exec")
        except SyntaxError as e:
            fallos += 1; print("✘ no compila:", py.name, e)
    for mjs in sorted((SKILL / "scripts").glob("*.mjs")):
        r = subprocess.run(["node", "--check", str(mjs)], capture_output=True, text=True)
        if r.returncode:
            fallos += 1; print("✘ no compila:", mjs.name, r.stderr.strip()[:200])
    print("Scripts: compilan")
    r = subprocess.run([sys.executable, str(SKILL / "scripts" / "sonidos.py"), "verificar"], capture_output=True, text=True)
    print(r.stdout.strip())
    fallos += r.returncode != 0
    n = sum(1 for p in SKILL.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    if n > 200:
        fallos += 1; print(f"✘ {n} archivos: claude.ai acepta como máximo 200 por skill")
    else:
        print(f"Archivos: {n} (máximo 200 en claude.ai)")
    sk = (SKILL / "SKILL.md").read_text(encoding="utf-8")
    if not sk.startswith("---\nname:") or "description:" not in sk.split("---")[1]:
        fallos += 1; print("✘ cabecera YAML de SKILL.md inválida")
    print("RESULTADO:", "OK" if not fallos else f"{fallos} fallo(s)")
    sys.exit(1 if fallos else 0)


if __name__ == "__main__":
    main()
