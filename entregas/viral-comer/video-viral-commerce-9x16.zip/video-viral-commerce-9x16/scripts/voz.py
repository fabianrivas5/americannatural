#!/usr/bin/env python3
"""Voz en off con tiempos por palabra. Cada salida <base> deja <base>.wav (48 kHz mono) y <base>.json:
{"fuente", "previsto", "duracion_s", "texto", "palabras": [{"palabra", "inicio", "fin"}]}  (segundos)

  voz.py tts       --texto-archivo f.txt --voz es-EC-LuisNeural [--velocidad +0%] [--proxy URL] --salida voz/cuerpo
  voz.py importar  --audio take.mp3 --palabras words.json [--texto-archivo f.txt] --salida voz/cuerpo
  voz.py estimar   --texto-archivo f.txt [--pps 2.5] --salida voz/cuerpo
  voz.py ensamblar --segmentos voz/apertura_A voz/cuerpo [--pausa 0.25] --salida voz/variante_A
  voz.py comparar  voz/apertura_A voz/apertura_B [--tolerancia 0.3]   (aperturas comparables: misma duración ±0,3 s)
"""
import argparse
import asyncio
import os
import subprocess
import sys
from pathlib import Path

from comun import duracion_audio, error, escribir_json, leer_json, tokens


def a_wav(origen, destino):
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(origen), "-ac", "1", "-ar", "48000", "-c:a", "pcm_s16le", str(destino)],
                   check=True)


def guardar(base, fuente, texto, palabras, previsto=False):
    base = Path(base)
    dur = duracion_audio(base.with_suffix(".wav"))
    escribir_json(base.with_suffix(".json"), {"fuente": fuente, "previsto": previsto, "duracion_s": round(dur, 3),
                                              "texto": texto, "palabras": palabras})
    print(f"{base}.wav  {dur:.3f} s · {len(palabras)} palabras · fuente {fuente}{' · PREVISTO' if previsto else ''}")


def leer_texto(a):
    return Path(a.texto_archivo).read_text(encoding="utf-8").strip() if a.texto_archivo else (a.texto or "").strip()


def cmd_tts(a):
    try:
        import edge_tts
    except ImportError:
        error("falta edge-tts: pip install edge-tts")
    texto = leer_texto(a) or error("texto vacío")
    base = Path(a.salida); base.parent.mkdir(parents=True, exist_ok=True)
    mp3 = base.with_suffix(".mp3")
    proxy = a.proxy or os.environ.get("HTTPS_PROXY") or None

    async def run():
        com = edge_tts.Communicate(texto, a.voz, rate=a.velocidad, boundary="WordBoundary", proxy=proxy)
        palabras = []
        with open(mp3, "wb") as f:
            async for ch in com.stream():
                if ch["type"] == "audio":
                    f.write(ch["data"])
                elif ch["type"] == "WordBoundary":
                    ini = ch["offset"] / 1e7
                    palabras.append({"palabra": ch["text"], "inicio": round(ini, 3), "fin": round(ini + ch["duration"] / 1e7, 3)})
        return palabras

    try:
        palabras = asyncio.run(run())
    except Exception as e:  # red bloqueada, voz inexistente…
        error(f"edge-tts falló ({type(e).__name__}: {e}). Usa 'importar' con otra voz o 'estimar' para tiempos previstos.")
    a_wav(mp3, base.with_suffix(".wav"))
    guardar(base, f"edge-tts:{a.voz}:{a.velocidad}", texto, palabras)


def cargar_palabras_externas(ruta):
    """Acepta ElevenLabs Scribe ({words:[{text,start,end,type}]}), Whisper (segments[].words[]), lista genérica o SRT/VTT."""
    ruta = Path(ruta)
    if ruta.suffix.lower() in (".srt", ".vtt"):
        import re
        out = []
        for m in re.finditer(r"(\d+:\d\d:\d\d[.,]\d+)\s*-->\s*(\d+:\d\d:\d\d[.,]\d+)[^\n]*\n(.+?)(?:\n\n|\Z)", ruta.read_text(encoding="utf-8"), re.S):
            t = lambda s: sum(float(x) * k for x, k in zip(s.replace(",", ".").split(":"), (3600, 60, 1)))
            ws = m.group(3).split(); i0, i1 = t(m.group(1)), t(m.group(2))
            for j, w in enumerate(ws):
                out.append({"palabra": w, "inicio": i0 + (i1 - i0) * j / len(ws), "fin": i0 + (i1 - i0) * (j + 1) / len(ws)})
        return out
    d = leer_json(ruta)
    if isinstance(d, dict) and "transcripts" in d:
        d = d["transcripts"][0]
    if isinstance(d, dict) and "segments" in d:
        d = [w for s in d["segments"] for w in s.get("words", [])]
    elif isinstance(d, dict):
        d = d.get("words") or d.get("palabras") or []
    out = []
    for w in d:
        if w.get("type", "word") != "word":
            continue
        txt = (w.get("text") or w.get("word") or w.get("palabra") or "").strip()
        ini = w.get("start", w.get("inicio")); fin = w.get("end", w.get("fin"))
        if txt and ini is not None:
            out.append({"palabra": txt, "inicio": round(float(ini), 3), "fin": round(float(fin if fin is not None else ini), 3)})
    if not out:
        error(f"no encontré palabras con tiempos en {ruta}")
    return out


def cmd_importar(a):
    base = Path(a.salida); base.parent.mkdir(parents=True, exist_ok=True)
    a_wav(a.audio, base.with_suffix(".wav"))
    palabras = cargar_palabras_externas(a.palabras)
    texto = leer_texto(a) or " ".join(p["palabra"] for p in palabras)
    guardar(base, f"importado:{Path(a.audio).name}", texto, palabras)


def cmd_estimar(a):
    texto = leer_texto(a) or error("texto vacío")
    base = Path(a.salida); base.parent.mkdir(parents=True, exist_ok=True)
    t, palabras, paso = 0.12, [], 1.0 / a.pps
    for tok in tokens(texto):
        palabras.append({"palabra": tok, "inicio": round(t, 3), "fin": round(t + paso * 0.9, 3)})
        t += paso + (0.38 if tok[-1] in ".?!¿¡" else 0.22 if tok[-1] in ",;:" else 0)
    dur = t + 0.3
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=mono", "-t", f"{dur:.3f}",
                    "-c:a", "pcm_s16le", str(base.with_suffix(".wav"))], check=True)
    guardar(base, f"estimado:{a.pps}pps", texto, palabras, previsto=True)


def cmd_ensamblar(a):
    salida = Path(a.salida); salida.parent.mkdir(parents=True, exist_ok=True)
    palabras, segs, textos, previsto, fuentes, t = [], [], [], False, [], 0.0
    lista = salida.with_suffix(".lista.txt")
    with open(lista, "w", encoding="utf-8") as L:
        for i, s in enumerate(a.segmentos):
            s = Path(s); d = leer_json(s.with_suffix(".json"))
            dur = duracion_audio(s.with_suffix(".wav"))
            for p in d["palabras"]:
                palabras.append({"palabra": p["palabra"], "inicio": round(p["inicio"] + t, 3), "fin": round(p["fin"] + t, 3)})
            segs.append({"nombre": s.name, "inicio": round(t, 3), "fin": round(t + dur, 3)})
            textos.append(d.get("texto", "")); previsto |= d.get("previsto", False); fuentes.append(d.get("fuente", "?"))
            L.write(f"file '{s.with_suffix('.wav').resolve()}'\n")
            t += dur
            if i < len(a.segmentos) - 1 and a.pausa > 0:
                sil = salida.parent / f"_silencio_{a.pausa:.3f}.wav"
                subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=mono", "-t", f"{a.pausa:.3f}",
                                "-c:a", "pcm_s16le", str(sil)], check=True)
                L.write(f"file '{sil.resolve()}'\n"); t += a.pausa
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lista), "-ac", "1", "-ar", "48000",
                    "-c:a", "pcm_s16le", str(salida.with_suffix(".wav"))], check=True)
    lista.unlink()
    base = salida
    dur = duracion_audio(base.with_suffix(".wav"))
    escribir_json(base.with_suffix(".json"), {"fuente": " + ".join(fuentes), "previsto": previsto, "duracion_s": round(dur, 3),
                                              "texto": " ".join(textos), "segmentos": segs, "palabras": palabras})
    print(f"{base}.wav  {dur:.3f} s · segmentos: " + ", ".join(f"{s['nombre']} {s['inicio']:.2f}–{s['fin']:.2f}" for s in segs))


def cmd_comparar(a):
    durs = {Path(b).name: duracion_audio(Path(b).with_suffix(".wav")) for b in a.bases}
    prev = any(leer_json(Path(b).with_suffix(".json")).get("previsto") for b in a.bases)
    dif = max(durs.values()) - min(durs.values())
    for n, d in durs.items():
        print(f"{n:<20} {d:.3f} s")
    ok = dif <= a.tolerancia
    print(f"diferencia {dif:.3f} s · {'OK' if ok else 'FUERA DE TOLERANCIA'} (±{a.tolerancia} s){' · PREVISTO' if prev else ''}")
    sys.exit(0 if ok else 1)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    s = p.add_subparsers(dest="cmd", required=True)
    for nombre, fn in (("tts", cmd_tts), ("importar", cmd_importar), ("estimar", cmd_estimar)):
        x = s.add_parser(nombre); x.set_defaults(fn=fn)
        x.add_argument("--texto"); x.add_argument("--texto-archivo"); x.add_argument("--salida", required=True)
    t = s.choices["tts"]; t.add_argument("--voz", default="es-EC-LuisNeural"); t.add_argument("--velocidad", default="+0%"); t.add_argument("--proxy")
    i = s.choices["importar"]; i.add_argument("--audio", required=True); i.add_argument("--palabras", required=True)
    s.choices["estimar"].add_argument("--pps", type=float, default=2.5)
    e = s.add_parser("ensamblar"); e.set_defaults(fn=cmd_ensamblar)
    e.add_argument("--segmentos", nargs="+", required=True); e.add_argument("--pausa", type=float, default=0.25); e.add_argument("--salida", required=True)
    c = s.add_parser("comparar"); c.set_defaults(fn=cmd_comparar)
    c.add_argument("bases", nargs="+"); c.add_argument("--tolerancia", type=float, default=0.3)
    a = p.parse_args(); a.fn(a)


if __name__ == "__main__":
    main()
