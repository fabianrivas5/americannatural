#!/usr/bin/env python3
"""storyboard.json + palabras.json (voz real o prevista) → timeline.json, planos.md, hoja_sonido.md/.tsv, subtitulos.srt/.json

  python3 plan_audio.py --storyboard storyboard.json --apertura A --palabras voz/variante_A.json --salida build_A
        [--catalogo-extra sonidos_propios.tsv] [--fps 30]

Alinea el texto del guion con los tiempos de la voz (tolera cifras escritas distinto u omisiones), calcula
entrada/salida de cada escena, cada micro-evento, cada bloque de subtítulos y cada efecto
(entrada de pista = t objetivo − punto de sincronía). Si cambias la narración, vuelve a correrlo: todo se mueve.
"""
import argparse
import csv
import difflib
import sys
from pathlib import Path

from comun import AMBIENTE_MIN_S, SKILL, cargar_catalogo, error, escribir_json, fmt_t, leer_json, normalizar, tokens

MAX_PAL_SUB, MAX_DUR_SUB = 5, 1.6
FUNCIONALES = {"y", "e", "o", "u", "el", "la", "los", "las", "un", "una", "a", "al", "de", "del", "que", "en", "tu", "su", "lo", "le", "por", "con", "para", "se", "te", "mi", "si", "ya", "no"}
AVISOS = []
NITIDEZ = {}


def aviso(msg):
    AVISOS.append(msg)
    print("AVISO:", msg, file=sys.stderr)


def alinear(guion, voz):
    """guion: lista de tokens normalizados; voz: lista de dicts palabra/inicio/fin. Devuelve [(inicio, fin)] por token del guion."""
    vn = [normalizar(p["palabra"]) for p in voz]
    res = [None] * len(guion)
    sm = difflib.SequenceMatcher(None, guion, vn, autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            for k in range(i2 - i1):
                res[i1 + k] = (voz[j1 + k]["inicio"], voz[j1 + k]["fin"])
        elif op == "replace":
            t0, t1 = voz[j1]["inicio"], voz[j2 - 1]["fin"]
            n = i2 - i1
            for k in range(n):
                res[i1 + k] = (t0 + (t1 - t0) * k / n, t0 + (t1 - t0) * (k + 1) / n)
            if abs((j2 - j1) - n) > 2:
                aviso(f"guion y voz difieren en «{' '.join(guion[i1:i2])}» ↔ «{' '.join(vn[j1:j2])}»: revisa que la voz diga el guion")
    # omisiones (palabras del guion que la voz no dijo): interpolar
    for i, r in enumerate(res):
        if r is None:
            prev = next((res[k][1] for k in range(i - 1, -1, -1) if res[k]), 0.0)
            nxt = next((res[k][0] for k in range(i + 1, len(res)) if res[k]), prev + 0.3)
            res[i] = (prev, max(prev, nxt))
            aviso(f"la voz no dice «{guion[i]}» (tiempo interpolado {prev:.2f} s)")
    return res


def resolver_ancla(en, esc, fps):
    """Instante absoluto de un ancla. 'desfase' (s, opcional) se suma: p. ej. el contacto de un objeto que rebota llega
    0,12 s después de que empieza su animación."""
    if en and "desfase" in en:
        return resolver_ancla({k: v for k, v in en.items() if k != "desfase"}, esc, fps) + float(en["desfase"])
    if en is None:
        return esc["entrada"]
    if "t" in en:
        return float(en["t"])
    if en.get("inicio_escena"):
        return esc["entrada"]
    if en.get("fin_escena"):
        return esc["salida"]
    if "t_escena" in en:
        return esc["entrada"] + float(en["t_escena"])
    if "palabra" in en:
        objetivo = [normalizar(x) for x in str(en["palabra"]).split()]
        occ = int(en.get("ocurrencia", 1)); vistas = 0
        pals = esc["palabras"]
        for i in range(len(pals) - len(objetivo) + 1):
            if [normalizar(p["palabra"]) for p in pals[i:i + len(objetivo)]] == objetivo:
                vistas += 1
                if vistas == occ:
                    return pals[i + len(objetivo) - 1]["fin"] if en.get("punto") == "fin" else pals[i]["inicio"]
        error(f"escena {esc['id']}: el ancla palabra «{en['palabra']}» (ocurrencia {occ}) no está en la frase "
              f"«{esc['voz']}». Si cambiaste la narración, reasigna el ancla.")
    error(f"escena {esc['id']}: ancla no reconocida {en}")


def describir_ancla(en):
    if en and "desfase" in en:
        return describir_ancla({k: v for k, v in en.items() if k != "desfase"}) + f" {float(en['desfase']):+.2f} s"
    if not en:
        return "inicio de escena"
    if "palabra" in en:
        return f"palabra «{en['palabra']}»" + (f" ({en['ocurrencia']}ª)" if en.get("ocurrencia", 1) != 1 else "") + (" fin" if en.get("punto") == "fin" else "")
    if "t_escena" in en:
        return f"{en['t_escena']:+.2f} s desde inicio de escena"
    if en.get("inicio_escena"):
        return "inicio de escena"
    if en.get("fin_escena"):
        return "fin de escena"
    return f"t={en.get('t')} s (absoluto)"


def subtitulos_escena(esc, resaltar):
    bloques, actual = [], []
    for k, p in enumerate(esc["palabras"]):
        actual.append(p)
        fin_frase = p["palabra"][-1] in ".,;:?!" if p["palabra"] else False
        dur = actual[-1]["fin"] - actual[0]["inicio"]
        resto = len(esc["palabras"]) - k - 1
        if len(actual) >= MAX_PAL_SUB or (fin_frase and len(actual) >= 2) or (dur > MAX_DUR_SUB and len(actual) >= 2):
            if resto == 1 and len(actual) < MAX_PAL_SUB:  # no dejar una palabra huérfana
                continue
            if not fin_frase and len(actual) > 2 and normalizar(actual[-1]["palabra"]) in FUNCIONALES:
                arrastre = [actual.pop()]  # no cerrar un bloque en "y", "el", "a"…: pasa al siguiente
                if len(actual) > 2 and normalizar(actual[-1]["palabra"]) in FUNCIONALES:
                    arrastre.insert(0, actual.pop())
                bloques.append(actual); actual = arrastre
            else:
                bloques.append(actual); actual = []
    if actual:
        if bloques and len(actual) == 1 and len(bloques[-1]) < MAX_PAL_SUB + 1:
            bloques[-1].extend(actual)
        else:
            bloques.append(actual)
    out = []
    res_n = {normalizar(r) for r in resaltar}
    for i, b in enumerate(bloques):
        ini = b[0]["inicio"]
        fin = bloques[i + 1][0]["inicio"] if i + 1 < len(bloques) else min(esc["salida"], b[-1]["fin"] + 0.35)
        out.append({"escena": esc["id"], "inicio": round(ini, 3), "fin": round(max(fin, ini + 0.4), 3),
                    "texto": " ".join(p["palabra"] for p in b), "posicion": esc.get("subtitulo_posicion", "abajo"),
                    "palabras": [{"palabra": p["palabra"], "inicio": round(p["inicio"], 3), "fin": round(p["fin"], 3),
                                  "resaltar": normalizar(p["palabra"]) in res_n} for p in b]})
    return out


def srt_t(s):
    ms = int(round(s * 1000)); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); se, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{se:02},{ms:03}"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--storyboard", required=True); ap.add_argument("--apertura", required=True)
    ap.add_argument("--palabras", required=True); ap.add_argument("--salida", required=True)
    ap.add_argument("--catalogo-extra"); ap.add_argument("--fps", type=int, default=30)
    a = ap.parse_args()

    sb = leer_json(a.storyboard); voz = leer_json(a.palabras)
    if a.apertura not in sb["aperturas"]:
        error(f"apertura {a.apertura} no existe; hay: {', '.join(sb['aperturas'])}")
    escenas = [dict(e) for e in sb["aperturas"][a.apertura]["escenas"]] + [dict(e) for e in sb["cuerpo"]]
    cat = cargar_catalogo(a.catalogo_extra)
    global NITIDEZ
    from sonidos import cargar_nitidez
    NITIDEZ = cargar_nitidez()
    previsto = bool(voz.get("previsto"))
    dur_total = float(voz["duracion_s"])

    # 1. alinear guion ↔ voz
    toks, dueno = [], []
    for k, e in enumerate(escenas):
        for t in tokens(e["voz"]):
            toks.append(t); dueno.append(k)
    tiempos = alinear([normalizar(t) for t in toks], voz["palabras"])
    for e in escenas:
        e["palabras"] = []
    for t, k, (i, f) in zip(toks, dueno, tiempos):
        escenas[k]["palabras"].append({"palabra": t, "inicio": round(i, 3), "fin": round(f, 3)})

    # 2. entrada/salida de escenas (la imagen llega 0,10 s antes de la primera palabra, sin pisar la anterior)
    for k, e in enumerate(escenas):
        if not e["palabras"]:
            error(f"escena {e['id']} sin voz")
        if k == 0:
            e["entrada"] = 0.0
        else:
            prev_fin = escenas[k - 1]["palabras"][-1]["fin"]
            e["entrada"] = round(max(prev_fin, e["palabras"][0]["inicio"] - 0.10), 3)
    for k, e in enumerate(escenas):
        e["salida"] = escenas[k + 1]["entrada"] if k + 1 < len(escenas) else round(dur_total, 3)
        if e["salida"] - e["entrada"] > 8.0:
            aviso(f"escena {e['id']} dura {e['salida'] - e['entrada']:.1f} s (> 8 s): divídela")
        e["t_palabra_clave"] = round(resolver_ancla({"palabra": e["palabra_clave"]}, e, a.fps), 3) if e.get("palabra_clave") else None

    # 3. micro-eventos
    for e in escenas:
        evs = []
        for ev in e.get("eventos", []):
            evs.append({"t": round(resolver_ancla(ev.get("en"), e, a.fps), 3), "que": ev["que"], "ancla": describir_ancla(ev.get("en"))})
        evs.sort(key=lambda x: x["t"])
        marcas = [e["entrada"]] + [x["t"] for x in evs] + [e["salida"]]
        hueco = max(b - c for c, b in zip(marcas, marcas[1:]))
        if hueco > 2.0:
            aviso(f"escena {e['id']}: {hueco:.1f} s sin micro-evento (máx. 2 s): añade uno")
        e["eventos_t"] = evs

    # 4. subtítulos
    subs = []
    for e in escenas:
        subs += subtitulos_escena(e, e.get("subtitulo_resaltar", []))

    # 5. sonidos
    sonidos = []
    for e in escenas:
        if not e.get("sonidos") and not e.get("sonido_decision"):
            aviso(f"escena {e['id']}: sin efecto ni 'sonido_decision' (si va con voz sola, escribe por qué)")
        for s in e.get("sonidos", []):
            f = cat.get(s["archivo"])
            if not f:
                error(f"escena {e['id']}: «{s['archivo']}» no existe en el catálogo. Busca uno real con sonidos.py buscar")
            if not Path(f["ruta"]).exists():
                error(f"falta el archivo {f['ruta']}")
            t_obj = resolver_ancla(s.get("en"), e, a.fps)
            larga = f["duracion_s"] >= AMBIENTE_MIN_S
            sync = f["pico_s"] if s.get("sync", "pico") == "pico" else float(s["sync"])
            nt = NITIDEZ.get(s["archivo"])
            if not larga and nt is not None and nt < 1.5 and s.get("sync", "pico") == "pico":
                aviso(f"escena {e['id']}: {s['archivo']} tiene pico poco definido (nitidez {nt} < 1,5): no sincroniza bien un gesto; "
                      "elige una pista con golpe claro o fija 'sync' de oído")
            if larga and s.get("sync", "pico") == "pico":
                aviso(f"{s['archivo']} es ambiente/pista larga: el pico ({f['pico_s']:.3f} s) no representa la acción; fija 'sync' de oído")
            entrada = t_obj - sync; recorte_ini = 0.0
            if entrada < 0:
                aviso(f"escena {e['id']}: {s['archivo']} tendría entrada {entrada:.3f} s; se recorta el inicio (el pico ya no cae en el gesto)")
                recorte_ini, entrada = -entrada, 0.0
            salida = entrada + f["duracion_s"] - recorte_ini; recortado = False
            if s.get("hasta"):
                t_h = resolver_ancla(s["hasta"], e, a.fps)
                if t_h < salida:
                    salida, recortado = t_h, True
            if salida > dur_total:
                salida, recortado = dur_total, True
            fade = float(s.get("fade_out", 0.08 if recortado else 0.0))
            if recortado and fade < 0.08:
                fade = 0.08
            sonidos.append({
                "escena": e["id"], "archivo": s["archivo"], "ruta": f["ruta"],
                "ruta_skill": str(Path(f["ruta"]).resolve().relative_to(SKILL)) if str(Path(f["ruta"]).resolve()).startswith(str(SKILL)) else f["ruta"],
                "activador": describir_ancla(s.get("en")), "gesto": s.get("gesto", e.get("accion_visible", "")),
                "t_objetivo": round(t_obj, 3), "sync_en_pista": round(sync, 3), "entrada": round(entrada, 3),
                "recorte_inicio": round(recorte_ini, 3), "salida": round(salida, 3), "recortado": recortado, "fade_out": fade,
                "nivel_db": float(s.get("nivel_db", -12)), "referencia_nivel": s.get("referencia_nivel", "rms" if larga else "pico"),
                "motivo": s.get("motivo") or error(f"escena {e['id']}: {s['archivo']} sin 'motivo'"),
                "origen": f.get("origen_segun_creditos", ""), "licencia": f.get("licencia_declarada", "")})
    sonidos.sort(key=lambda x: x["t_objetivo"])
    for s in sonidos:
        cerca = [o for o in sonidos if abs(o["t_objetivo"] - s["t_objetivo"]) <= 0.25]
        if len(cerca) > 2:
            aviso(f"{len(cerca)} efectos en 0,5 s alrededor de {s['t_objetivo']:.2f} s: satura; deja máx. 2")
            break

    # 6. salidas
    out = Path(a.salida); out.mkdir(parents=True, exist_ok=True)
    timeline = {
        "producto": sb.get("producto"), "apertura": a.apertura, "fps": a.fps, "resolucion": sb.get("resolucion", [1080, 1920]),
        "duracion_s": round(dur_total, 3), "previsto": previsto, "fuente_voz": voz.get("fuente"),
        "shared": sb.get("shared", {}), "musica": sb.get("musica"),
        "escenas": [{k: e.get(k) for k in ("id", "funcion", "voz", "palabra_clave", "t_palabra_clave", "accion_visible", "encuadre",
                                             "transicion_entrada", "evidencia", "entrada", "salida", "subtitulo_posicion",
                                             "sonido_decision", "palabras")} | {"eventos": e["eventos_t"], "visual": e.get("visual", {})}
                    for e in escenas],
        "subtitulos": subs, "sonidos": sonidos, "avisos": AVISOS}
    escribir_json(out / "timeline.json", timeline)
    escribir_json(out / "subtitulos.json", subs)
    with open(out / "subtitulos.srt", "w", encoding="utf-8") as f:
        for i, s in enumerate(subs, 1):
            f.write(f"{i}\n{srt_t(s['inicio'])} --> {srt_t(s['fin'])}\n{s['texto']}\n\n")

    marca = " (PREVISTO: tiempos estimados, recalcular con la voz real)" if previsto else ""
    cols = ["#", "Escena", "Archivo", "Ruta", "Activador", "Gesto / acción visible", "t objetivo", "Sync en pista", "Entrada", "Salida",
            "Nivel vs voz", "Motivo", "Origen"]
    with open(out / "hoja_sonido.tsv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t"); w.writerow(cols)
        for i, s in enumerate(sonidos, 1):
            w.writerow([i, s["escena"], s["archivo"], s["ruta_skill"], s["activador"], s["gesto"], f"{s['t_objetivo']:.3f}",
                        f"{s['sync_en_pista']:.3f}", f"{s['entrada']:.3f}", f"{s['salida']:.3f}",
                        f"{s['nivel_db']:+.0f} dB ({s['referencia_nivel']})", s["motivo"], s["origen"]])
    with open(out / "hoja_sonido.md", "w", encoding="utf-8") as f:
        f.write(f"# Hoja de sonido · apertura {a.apertura}{marca}\n\nVoz: {voz.get('fuente')} · duración {dur_total:.3f} s · "
                f"entrada de pista = t objetivo − sync en pista\n\n| " + " | ".join(c for c in cols if c != "Ruta") + " |\n|" + "---|" * (len(cols) - 1) + "\n")
        for i, s in enumerate(sonidos, 1):
            f.write(f"| {i} | {s['escena']} | `{s['ruta_skill']}` | {s['activador']} | {s['gesto']} | {fmt_t(s['t_objetivo'])} | "
                    f"{s['sync_en_pista']:.3f} | {fmt_t(s['entrada'])} | {fmt_t(s['salida'])}{' ✂' if s['recortado'] else ''} | "
                    f"{s['nivel_db']:+.0f} dB {s['referencia_nivel']} | {s['motivo']} | {s['origen']} |\n")
        solo = [e for e in escenas if e.get("sonido_decision")]
        if solo:
            f.write("\n**Escenas con decisión de sonido explícita:**\n\n" + "".join(f"- {e['id']}: {e['sonido_decision']}\n" for e in solo))
        if sb.get("musica"):
            m = sb["musica"]; f.write(f"\n**Música:** `{m.get('archivo')}` · {m.get('nivel_db', -22)} dB RMS bajo la voz · ducking · origen: {m.get('origen', 'FALTA ORIGEN')}\n")
    with open(out / "planos.md", "w", encoding="utf-8") as f:
        f.write(f"# Planos por segundo · apertura {a.apertura}{marca}\n\n| Escena | Función | Entrada | Salida | Voz | Palabra clave | Acción visible | "
                "Encuadre | Transición | Sonido | Evidencia |\n|---|---|---|---|---|---|---|---|---|---|---|\n")
        for e in escenas:
            sn = ", ".join(f"{s['archivo']} @{s['t_objetivo']:.2f}" for s in sonidos if s["escena"] == e["id"]) or (e.get("sonido_decision") or "—")
            pk = f"«{e['palabra_clave']}» {e['t_palabra_clave']:.2f} s" if e.get("palabra_clave") else "—"
            f.write(f"| {e['id']} | {e.get('funcion', '')} | {fmt_t(e['entrada'])} | {fmt_t(e['salida'])} | {e['voz']} | {pk} | "
                    f"{e.get('accion_visible', '')} | {e.get('encuadre', '')} | {e.get('transicion_entrada', '')} | {sn} | {e.get('evidencia', '—')} |\n")
        f.write("\n## Micro-eventos\n\n")
        for e in escenas:
            f.write(f"**{e['id']}** ({fmt_t(e['entrada'])}–{fmt_t(e['salida'])}): " +
                    " · ".join(f"{fmt_t(x['t'])} {x['que']}" for x in e["eventos_t"]) + "\n\n")
        f.write("## Subtítulos\n\n| Inicio | Fin | Texto (resaltado en **negrita**) |\n|---|---|---|\n")
        for s in subs:
            txt = " ".join(f"**{p['palabra']}**" if p["resaltar"] else p["palabra"] for p in s["palabras"])
            f.write(f"| {fmt_t(s['inicio'])} | {fmt_t(s['fin'])} | {txt} |\n")
        if AVISOS:
            f.write("\n## Avisos\n\n" + "".join(f"- {x}\n" for x in AVISOS))
    print(f"OK → {out}/ · {len(escenas)} escenas · {len(subs)} subtítulos · {len(sonidos)} efectos · {len(AVISOS)} avisos"
          f"{' · PREVISTO' if previsto else ''}")


if __name__ == "__main__":
    main()
