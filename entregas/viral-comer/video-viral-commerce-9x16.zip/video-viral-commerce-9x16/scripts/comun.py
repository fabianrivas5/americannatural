"""Utilidades compartidas de la skill video-viral-commerce-9x16 (solo biblioteca estándar + ffmpeg)."""
import csv
import json
import re
import subprocess
import sys
import unicodedata
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
RECURSOS = SKILL / "recursos"
SONIDOS = RECURSOS / "sonidos"
CATALOGO = RECURSOS / "catalogo_sonidos.tsv"
AMBIENTE_MIN_S = 4.0  # a partir de esta duración el nivel se mide en RMS y el pico no sirve de sync


def error(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def cargar_catalogo(extra=None):
    """Devuelve {archivo: fila} con 'ruta' absoluta. extra = TSV de sonidos propios (mismo formato, ruta relativa al TSV)."""
    cat = {}
    fuentes = [(CATALOGO, SONIDOS)]
    if extra:
        extra = Path(extra)
        fuentes.append((extra, extra.parent))
    for tsv, base in fuentes:
        with open(tsv, encoding="utf-8", newline="") as f:
            for fila in csv.DictReader(f, delimiter="\t"):
                fila["duracion_s"] = float(fila["duracion_s"])
                fila["pico_s"] = float(fila["primer_pico_absoluto_s_decodificado"])
                ruta = Path(fila.get("ruta") or fila["archivo"])
                if not ruta.is_absolute():
                    ruta = (base / ruta) if (base / ruta).exists() else (base / "sonidos_propios" / ruta)
                fila["ruta"] = str(ruta)
                cat[fila["archivo"]] = fila
    return cat


def normalizar(palabra):
    s = unicodedata.normalize("NFD", str(palabra).lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9ñ]+", "", s)


def tokens(texto):
    """Palabras visibles del texto (conservan puntuación para subtítulos)."""
    return [t for t in re.split(r"\s+", texto.strip()) if normalizar(t)]


def leer_json(ruta):
    with open(ruta, encoding="utf-8") as f:
        return json.load(f)


def escribir_json(ruta, datos):
    Path(ruta).parent.mkdir(parents=True, exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)


def duracion_audio(ruta):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(ruta)],
                         capture_output=True, text=True, check=True).stdout.strip()
    return float(out)


def niveles(ruta):
    """(pico_db, rms_db) de un archivo de audio con volumedetect."""
    err = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(ruta), "-af", "volumedetect", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    pico = re.search(r"max_volume:\s*(-?[\d.]+|-inf) dB", err)
    rms = re.search(r"mean_volume:\s*(-?[\d.]+|-inf) dB", err)
    if not pico or not rms:
        error(f"no pude medir niveles de {ruta}")
    f = lambda m: -120.0 if m.group(1) == "-inf" else float(m.group(1))
    return f(pico), f(rms)


def fmt_t(s):
    return f"{s:06.3f}".replace(".", ",")
