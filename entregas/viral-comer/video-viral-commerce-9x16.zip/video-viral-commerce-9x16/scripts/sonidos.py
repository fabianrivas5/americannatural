#!/usr/bin/env python3
"""Consulta el banco de 142 efectos: buscar, info, colocar (entrada = t - pico) y verificar archivos/catálogo/SHA-256.

  python3 sonidos.py buscar whoosh
  python3 sonidos.py buscar --categoria "Golpes y énfasis" --max-dur 0.6
  python3 sonidos.py info papel-1.ogg
  python3 sonidos.py colocar papel-1.ogg --t 1.6 [--sync 0.3]
  python3 sonidos.py verificar
  python3 sonidos.py nitidez            # (re)genera recursos/nitidez_pico.tsv: qué tan definido es el pico de cada pista
"""
import argparse
import hashlib
import sys
from pathlib import Path

from comun import CATALOGO, RECURSOS, SONIDOS, cargar_catalogo, normalizar


def fila_corta(f):
    nt = cargar_nitidez().get(f["archivo"])
    marca = "" if nt is None else (f" nít {nt:>4.1f}" + ("" if nt >= 1.5 else "!"))
    return (f"{f['archivo']:<22} {f['duracion_s']:>7.3f} s  pico {f['pico_s']:>6.3f} s{marca}  "
            f"{f['categoria_editorial_propuesta']:<28} {f['origen_segun_creditos'][:60]}")


def cmd_buscar(a):
    cat = cargar_catalogo()
    q = normalizar(a.texto or "")
    res = []
    for f in cat.values():
        hay = normalizar(f["archivo"] + f["familia_por_nombre"] + f["categoria_editorial_propuesta"])
        if q and q not in hay:
            continue
        if a.categoria and normalizar(a.categoria) not in normalizar(f["categoria_editorial_propuesta"]):
            continue
        if a.max_dur and f["duracion_s"] > a.max_dur:
            continue
        res.append(f)
    for f in sorted(res, key=lambda x: x["archivo"]):
        print(fila_corta(f))
    print(f"— {len(res)} resultado(s)")


def cmd_info(a):
    cat = cargar_catalogo()
    f = cat.get(a.archivo) or sys.exit(f"ERROR: {a.archivo} no está en el catálogo")
    for k, v in f.items():
        if k not in ("pico_s",):
            print(f"{k:<40} {v}")
    print(f"{'existe':<40} {Path(f['ruta']).exists()}")
    nt = cargar_nitidez().get(a.archivo)
    if nt is not None:
        print(f"{'nitidez_pico':<40} {nt}" + ("" if nt >= 1.5 else "  → textura sin golpe dominante: sync de oído"))


def cmd_colocar(a):
    cat = cargar_catalogo()
    f = cat.get(a.archivo) or sys.exit(f"ERROR: {a.archivo} no está en el catálogo")
    sync = a.sync if a.sync is not None else f["pico_s"]
    entrada = a.t - sync
    print(f"{a.archivo}: sync {sync:.3f} s en la pista → entrada {entrada:.3f} s, salida {entrada + f['duracion_s']:.3f} s")
    if entrada < 0:
        print("AVISO: entrada negativa; el pico no puede caer en ese instante (elige otra pista o ancla).")
    nt = cargar_nitidez().get(a.archivo)
    if nt is not None and nt < 1.5 and a.sync is None:
        print(f"AVISO: pico poco definido (nitidez {nt}): no sirve de punto de sincronía; usa --sync de oído o una pista con golpe claro.")
    if f["duracion_s"] >= 4 and a.sync is None:
        print("AVISO: pista larga/ambiente: el pico absoluto no representa la acción; usa --sync elegido de oído.")


def cmd_verificar(a):
    cat = cargar_catalogo()
    ogg = sorted(p.name for p in SONIDOS.glob("*.ogg"))
    faltan = [n for n in cat if not Path(cat[n]["ruta"]).exists()]
    sobran = [n for n in ogg if n not in cat]
    ok = True
    print(f"Catálogo: {len(cat)} filas · carpeta: {len(ogg)} OGG")
    if faltan:
        ok = False; print("Faltan en carpeta:", ", ".join(faltan))
    if sobran:
        ok = False; print("Sin fila en catálogo:", ", ".join(sobran))
    sums = RECURSOS / "SHA256SUMS.txt"
    malos = n = 0
    for linea in sums.read_text(encoding="utf-8").splitlines():
        if not linea.strip():
            continue
        h, rel = linea.split(None, 1)
        p = RECURSOS / rel.strip().lstrip("*")
        n += 1
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest() != h:
            malos += 1; ok = False; print("SHA-256 no coincide / falta:", rel)
    print(f"SHA-256: {n - malos}/{n} correctos")
    if not (SONIDOS / "CREDITOS.md").exists():
        ok = False; print("Falta recursos/sonidos/CREDITOS.md")
    print("OK" if ok else "FALLOS")
    sys.exit(0 if ok else 1)


def medir_nitidez(ruta, pico_s):
    """Envolvente RMS en ventanas de 5 ms: nivel alrededor del pico del catálogo (±10 ms) dividido por el mayor nivel
    fuera de ±40 ms. ≥ 1,5 = golpe claro (sirve de punto de sincronía). < 1,5 = textura o varios golpes parecidos:
    el pico depende del decodificador y del códec final; elige 'sync' de oído o una pista con golpe claro."""
    import array, math, subprocess
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", ruta, "-ac", "1", "-ar", "48000", "-f", "s16le", "-"],
                         capture_output=True, check=True).stdout
    a = array.array("h"); a.frombytes(raw); n = 240  # 5 ms
    env = [math.sqrt(sum(x * x for x in a[k:k + n]) / max(1, len(a[k:k + n]))) for k in range(0, len(a), n)]
    c = int(pico_s * 48000 / n)
    cerca = max(env[max(0, c - 2):c + 3] or [0])
    fuera = env[:max(0, c - 8)] + env[c + 9:]
    return round(cerca / (max(fuera) if fuera and max(fuera) > 0 else 1e-9), 2) if fuera else 99.0


def cmd_nitidez(a):
    cat = cargar_catalogo()
    salida = RECURSOS / "nitidez_pico.tsv"
    with open(salida, "w", encoding="utf-8") as f:
        f.write("archivo\tnitidez_pico\tpico_definido\n")
        for n in sorted(cat):
            r = medir_nitidez(cat[n]["ruta"], cat[n]["pico_s"])
            f.write(f"{n}\t{r}\t{'sí' if r >= 1.5 else 'no'}\n")
    print(f"{salida}: {len(cat)} pistas")


def cargar_nitidez():
    p = RECURSOS / "nitidez_pico.tsv"
    if not p.exists():
        return {}
    filas = p.read_text(encoding="utf-8").splitlines()[1:]
    return {l.split("\t")[0]: float(l.split("\t")[1]) for l in filas if l.strip()}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    s = p.add_subparsers(dest="cmd", required=True)
    b = s.add_parser("buscar"); b.add_argument("texto", nargs="?"); b.add_argument("--categoria"); b.add_argument("--max-dur", type=float)
    b.set_defaults(fn=cmd_buscar)
    i = s.add_parser("info"); i.add_argument("archivo"); i.set_defaults(fn=cmd_info)
    c = s.add_parser("colocar"); c.add_argument("archivo"); c.add_argument("--t", type=float, required=True)
    c.add_argument("--sync", type=float, help="punto de sincronía elegido de oído (s); por defecto el pico del catálogo")
    c.set_defaults(fn=cmd_colocar)
    v = s.add_parser("verificar"); v.set_defaults(fn=cmd_verificar)
    n = s.add_parser("nitidez"); n.set_defaults(fn=cmd_nitidez)
    a = p.parse_args(); a.fn(a)


if __name__ == "__main__":
    main()
