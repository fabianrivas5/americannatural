#!/usr/bin/env python3
"""calendario.csv (4 semanas) → calendario.ics (importable) + calendario.html (vista por semanas).

  python3 calendario.py --csv calendario.csv --salida calendario [--zona America/Guayaquil] [--duracion-min 30]

Columnas: fecha (AAAA-MM-DD), hora (HH:MM), producto, pilar, gancho_A, gancho_B, objetivo, estado (idea|guion|producido|publicado)
Vuelve a correrlo cada vez que Gabo marque una pieza como publicada.
"""
import argparse
import csv
import datetime as dt
import html
import uuid
from pathlib import Path

COLOR = {"idea": "#9aa4b2", "guion": "#f0b400", "producido": "#2f80ed", "publicado": "#27ae60"}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--csv", required=True); ap.add_argument("--salida", required=True)
    ap.add_argument("--zona", default="America/Guayaquil"); ap.add_argument("--duracion-min", type=int, default=30)
    a = ap.parse_args()
    filas = list(csv.DictReader(open(a.csv, encoding="utf-8")))
    for f in filas:
        f["_dt"] = dt.datetime.strptime(f"{f['fecha']} {f.get('hora') or '19:00'}", "%Y-%m-%d %H:%M")
    filas.sort(key=lambda f: f["_dt"])
    sal = Path(a.salida); sal.parent.mkdir(parents=True, exist_ok=True)
    esc = lambda s: s.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")
    ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//American Natural//Video viral commerce//ES", "CALSCALE:GREGORIAN"]
    ahora = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    for f in filas:
        ini = f["_dt"]; fin = ini + dt.timedelta(minutes=a.duracion_min)
        uid = uuid.uuid5(uuid.NAMESPACE_URL, f"{f['fecha']}{f['producto']}{f['gancho_A']}")
        ics += ["BEGIN:VEVENT", f"UID:{uid}@american-natural", f"DTSTAMP:{ahora}",
                f"DTSTART;TZID={a.zona}:{ini:%Y%m%dT%H%M%S}", f"DTEND;TZID={a.zona}:{fin:%Y%m%dT%H%M%S}",
                f"SUMMARY:{esc('[' + f.get('estado', 'idea') + '] ' + f['producto'] + ' · ' + f['pilar'])}",
                f"DESCRIPTION:{esc('A: ' + f['gancho_A'] + chr(10) + 'B: ' + f.get('gancho_B', '') + chr(10) + 'Objetivo: ' + f.get('objetivo', ''))}",
                "END:VEVENT"]
    ics.append("END:VCALENDAR")
    sal.with_suffix(".ics").write_text("\r\n".join(ics) + "\r\n", encoding="utf-8")

    semanas = {}
    for f in filas:
        lunes = (f["_dt"] - dt.timedelta(days=f["_dt"].weekday())).date()
        semanas.setdefault(lunes, []).append(f)
    h = ["<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>",
         "<title>Calendario de videos</title><style>body{font-family:system-ui,sans-serif;margin:16px;background:#fff;color:#111}"
         ".s{margin:18px 0}.c{border-left:6px solid;padding:8px 12px;margin:6px 0;background:#f6f7f9;border-radius:6px}"
         "small{color:#555}@media(prefers-color-scheme:dark){body{background:#111;color:#eee}.c{background:#1d1f23}small{color:#aaa}}</style>",
         "<h1>Calendario de videos · 4 semanas</h1>"]
    for i, (lunes, fs) in enumerate(sorted(semanas.items()), 1):
        pub = sum(1 for f in fs if f.get("estado") == "publicado")
        h.append(f"<div class='s'><h2>Semana {i} · {lunes:%d/%m} <small>({pub}/{len(fs)} publicados)</small></h2>")
        for f in fs:
            e = f.get("estado", "idea")
            h.append(f"<div class='c' style='border-color:{COLOR.get(e, '#999')}'><b>{f['_dt']:%a %d/%m %H:%M}</b> · "
                     f"{html.escape(f['producto'])} · <i>{html.escape(f['pilar'])}</i> · <small>{html.escape(e)}</small><br>"
                     f"A: {html.escape(f['gancho_A'])}<br>B: {html.escape(f.get('gancho_B', ''))}<br>"
                     f"<small>Objetivo: {html.escape(f.get('objetivo', ''))}</small></div>")
        h.append("</div>")
    sal.with_suffix(".html").write_text("\n".join(h), encoding="utf-8")
    print(f"{sal}.ics y {sal}.html · {len(filas)} piezas · {sum(1 for f in filas if f.get('estado') == 'publicado')} publicadas")


if __name__ == "__main__":
    main()
