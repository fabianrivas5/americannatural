#!/usr/bin/env python3
"""Mide en el audio del MP4 exportado dónde cae el pico de cada efecto y lo compara con su t objetivo.

  python3 medir_sincronia.py video_final_9x16_A.mp4 build_A/timeline.json [--tolerancia-ms 33]

Sirve para detectar efectos cuyo pico "se mueve" tras la mezcla y el AAC (pistas sin golpe dominante).
Fiable cuando la voz aún es silencio (tiempos previstos) o en una exportación de solo efectos; con voz real, la
voz puede enmascarar el pico: exporta una pasada de efectos (mezclar.py con una voz en silencio) para medir.
Los efectos con 'sync' manual (texturas, sync 0) se listan pero no cuentan para el resultado.
"""
import argparse
import array
import json
import subprocess
import sys


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video"); ap.add_argument("timeline"); ap.add_argument("--tolerancia-ms", type=float, default=33.3)
    a = ap.parse_args()
    tl = json.load(open(a.timeline, encoding="utf-8")); sr = 48000
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", a.video, "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"],
                         capture_output=True, check=True).stdout
    x = array.array("h"); x.frombytes(raw)
    peor = 0.0
    for s in tl["sonidos"]:
        i0 = int(s["entrada"] * sr); i1 = int(min(s["salida"], s["entrada"] + s["sync_en_pista"] + 0.15) * sr)
        seg = x[i0:i1]
        if not seg:
            continue
        k = max(range(len(seg)), key=lambda j: abs(seg[j]))
        t = (i0 + k) / sr; d = (t - s["t_objetivo"]) * 1000
        manual = s["sync_en_pista"] == 0
        if not manual:
            peor = max(peor, abs(d))
        print(f"{s['escena']:<3} {s['archivo']:<20} objetivo {s['t_objetivo']:7.3f}  pico medido {t:7.3f}  Δ {d:+6.1f} ms"
              + ("  (sync manual: no cuenta)" if manual else ""))
    ok = peor <= a.tolerancia_ms
    print(f"máx |Δ| efectos con golpe = {peor:.1f} ms (1 fotograma = 33,3 ms) · {'OK' if ok else 'FUERA DE TOLERANCIA'}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
