#!/usr/bin/env python3
"""Revisión de un MP4 exportado contra su timeline.json.

  python3 revisar.py --video video_final_9x16_A.mp4 --timeline build_A/timeline.json --salida build_A/revision

Automático: formato (1080×1920, 30 fps, H.264 yuv420p, AAC, faststart), duración vs voz, tramos estáticos > 2 s
(freezedetect), sonoridad EBU R128. Extrae el fotograma de cada palabra clave con la zona segura dibujada y una hoja
de contacto, y deja revision.md con la tabla de correcciones (segundo · se oye · se ve · defecto · corrección · estado).
"""
import argparse
import json
import re
import subprocess
from pathlib import Path

from comun import fmt_t, leer_json
from mezclar import medir_r128

ZONA = {"arriba": 120, "abajo": 250, "derecha": 140}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--video", required=True); ap.add_argument("--timeline", required=True); ap.add_argument("--salida", required=True)
    a = ap.parse_args()
    tl = leer_json(a.timeline); out = Path(a.salida); (out / "fotogramas").mkdir(parents=True, exist_ok=True)
    pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", a.video],
                                   capture_output=True, text=True, check=True).stdout)
    v = next(s for s in pr["streams"] if s["codec_type"] == "video")
    au = next((s for s in pr["streams"] if s["codec_type"] == "audio"), None)
    dur = float(pr["format"]["duration"]); num, den = map(int, v["r_frame_rate"].split("/"))
    cab = Path(a.video).read_bytes()[:4_000_000]
    faststart = 0 <= cab.find(b"moov") < (cab.find(b"mdat") if cab.find(b"mdat") >= 0 else 10**9)
    chequeos = [
        ("Resolución 1080×1920", f"{v['width']}×{v['height']}", (v["width"], v["height"]) == (1080, 1920)),
        ("30 fps", f"{num / den:.3f}", abs(num / den - tl.get("fps", 30)) < 0.01),
        ("H.264 yuv420p", f"{v['codec_name']} {v.get('pix_fmt')}", v["codec_name"] == "h264" and v.get("pix_fmt") == "yuv420p"),
        ("Audio AAC", au["codec_name"] if au else "sin audio", bool(au) and au["codec_name"] == "aac"),
        ("faststart (moov al inicio)", "sí" if faststart else "no", faststart),
        ("Duración = voz ±0,1 s", f"{dur:.3f} vs {tl['duracion_s']:.3f}", abs(dur - tl["duracion_s"]) <= 0.1),
    ]
    err = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", a.video, "-vf", "scale=270:-2,freezedetect=n=0.003:d=2",
                          "-map", "0:v", "-f", "null", "-"], capture_output=True, text=True).stderr
    ini = [float(x) for x in re.findall(r"freeze_start: ([\d.]+)", err)]
    fin = [float(x) for x in re.findall(r"freeze_end: ([\d.]+)", err)] + [dur]
    estaticos = list(zip(ini, fin))
    chequeos.append(("Sin tramos estáticos > 2 s", ", ".join(f"{fmt_t(i)}–{fmt_t(f)}" for i, f in estaticos) or "ninguno", not estaticos))
    mb = Path(a.video).stat().st_size / 1e6; mbps = float(pr["format"].get("bit_rate", 0)) / 1e6
    chequeos.append(("Peso razonable (≤ 8 Mb/s)", f"{mb:.1f} MB · {mbps:.1f} Mb/s", mbps <= 8.0))
    if au:
        r = medir_r128(a.video)
        if tl.get("previsto"):  # sin voz real la sonoridad no es evaluable: se informa, no cuenta como fallo
            chequeos.append(("Sonoridad −14 ±1 LUFS", f"{r['lufs_integrados']} LUFS · NO APLICA: vista previa sin voz real", True))
        else:
            chequeos.append(("Sonoridad −14 ±1 LUFS", f"{r['lufs_integrados']} LUFS · LRA {r['lra_lu']} LU", abs(r["lufs_integrados"] + 14) <= 1))
        chequeos.append(("Pico real ≤ −1 dBTP", f"{r['pico_real_dbtp']} dBTP", r["pico_real_dbtp"] <= -1.0))

    # fotogramas en palabras clave
    caja = (f"drawbox=x=0:y={ZONA['arriba']}:w=iw-{ZONA['derecha']}:h=ih-{ZONA['arriba'] + ZONA['abajo']}:color=red@0.6:t=4")
    filas, jpgs = [], []
    for e in tl["escenas"]:
        t = e.get("t_palabra_clave") or (e["entrada"] + e["salida"]) / 2
        t = min(t + 0.04, dur - 0.05)
        jpg = out / "fotogramas" / f"{e['id']}_{t:06.2f}s.jpg"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.3f}", "-i", a.video, "-frames:v", "1", "-vf", caja + ",scale=540:-2",
                        "-q:v", "3", str(jpg)], check=True)
        jpgs.append(jpg)
        sfx = ", ".join(s["archivo"] for s in tl["sonidos"] if s["escena"] == e["id"] and abs(s["t_objetivo"] - t) < 0.6) or "—"
        filas.append(f"| {fmt_t(t)} | «{e.get('palabra_clave') or '—'}» — {e['voz']} | {e.get('accion_visible', '')} | {sfx} | "
                     f"`fotogramas/{jpg.name}` | | | pendiente de mirar |")
    lista = out / "_lista.txt"
    lista.write_text("".join(f"file '{j.resolve()}'\nduration 1\n" for j in jpgs), encoding="utf-8")
    cols = 4; rows = (len(jpgs) + cols - 1) // cols
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lista), "-vf",
                    f"scale=270:-2,tile={cols}x{rows}:padding=6:color=white", "-frames:v", "1", str(out / "hoja_contacto.jpg")], check=True)
    lista.unlink()

    ok = all(c[2] for c in chequeos)
    with open(out / "revision.md", "w", encoding="utf-8") as f:
        f.write(f"# Revisión · {Path(a.video).name} · apertura {tl.get('apertura')}\n\n")
        if tl.get("previsto"):
            f.write("> **Tiempos PREVISTOS**: la voz no es la definitiva. Repetir esta revisión con la voz real.\n\n")
        f.write("## Técnica (automático)\n\n| Control | Medido | Resultado |\n|---|---|---|\n")
        for n, m, b in chequeos:
            f.write(f"| {n} | {m} | {'✔' if b else '✘'} |\n")
        f.write("\n## Fotogramas en palabra clave (zona segura en rojo) — `hoja_contacto.jpg`\n\n"
                "| Segundo | Se oye | Debe verse | Efecto | Fotograma | Defecto | Corrección | Estado |\n|---|---|---|---|---|---|---|---|\n")
        f.write("\n".join(filas) + "\n")
        f.write("\nMirar en cada fotograma: imagen = palabra en ese instante (≤ 2 fotogramas), sujeto legible en móvil, continuidad de "
                "frasco/luz/color, nada cortado ni bajo botones o descripción, subtítulo sin tapar sujeto/etiqueta, pico del efecto en el gesto.\n")
        f.write("\n## Escucha (manual)\n\n- [ ] voz + efectos juntos, sin saturación ni desfase\n- [ ] palabra clave y CTA claros en `mezcla_mono.wav`\n"
                "- [ ] CTA claro en `mezcla_telefono.wav` (altavoz de teléfono)\n- [ ] ninguna pista termina de golpe\n")
        if tl.get("avisos"):
            f.write("\n## Avisos del plan\n\n" + "".join(f"- {x}\n" for x in tl["avisos"]))
    print(f"{'OK' if ok else 'HAY FALLOS'} → {out}/revision.md · {len(jpgs)} fotogramas · " +
          " · ".join(f"{n}: {'✔' if b else '✘ ' + m}" for n, m, b in chequeos))


if __name__ == "__main__":
    main()
