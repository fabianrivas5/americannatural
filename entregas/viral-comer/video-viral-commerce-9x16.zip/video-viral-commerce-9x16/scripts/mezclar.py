#!/usr/bin/env python3
"""Mezcla voz + efectos (+ música con ducking) según timeline.json y masteriza a −14 LUFS / ≤ −1 dBTP.

  python3 mezclar.py --timeline build_A/timeline.json --voz voz/variante_A.wav --salida build_A/mezcla.wav
        [--lufs -14] [--tp -1.5] [--musica pista.mp3 --musica-db -22]

nivel_db de cada efecto: 'pico' = pico del efecto respecto al pico de la voz; 'rms' = RMS respecto al RMS de la voz.
Deja además <salida>_mono.wav, <salida>_telefono.wav (300–3400 Hz) y <salida>_informe.json (LUFS, LRA, dBTP, ganancias).
"""
import argparse
import json
import re
import subprocess
import tempfile
from pathlib import Path

from comun import error, escribir_json, leer_json, niveles


def medir_r128(ruta):
    err = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(ruta), "-af", "ebur128=peak=true", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    resumen = err[err.rfind("Summary:"):]
    g = lambda pat: float(re.search(pat, resumen, re.S).group(1))
    return {"lufs_integrados": g(r"I:\s+(-?[\d.]+) LUFS"), "lra_lu": g(r"LRA:\s+(-?[\d.]+) LU"),
            "pico_real_dbtp": g(r"Peak:\s+(-?[\d.]+) dBFS")}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--timeline", required=True); ap.add_argument("--voz", required=True); ap.add_argument("--salida", required=True)
    ap.add_argument("--lufs", type=float, default=-14.0); ap.add_argument("--tp", type=float, default=-1.5)
    ap.add_argument("--musica"); ap.add_argument("--musica-db", type=float)
    a = ap.parse_args()

    tl = leer_json(a.timeline); salida = Path(a.salida); salida.parent.mkdir(parents=True, exist_ok=True)
    voz_pico, voz_rms = niveles(a.voz)
    voz_silencio = voz_pico <= -60
    if tl.get("previsto") and not voz_silencio:
        print("AVISO: timeline con tiempos PREVISTOS sobre una voz real: corre plan_audio.py con las palabras de esta voz")
    if voz_silencio:
        print("AVISO: voz prevista/silencio: vista previa SOLO de efectos, ganancias contra una voz de referencia de −3 dB pico / "
              "−20 dB RMS y sin loudnorm (no es la mezcla final; repetir con la voz real)")
        voz_pico, voz_rms = -3.0, -20.0
    entradas, filtros, etiquetas, informe = ["-i", a.voz], [], [], []
    cache = {}
    for i, s in enumerate(tl["sonidos"], start=1):
        if not Path(s["ruta"]).exists():
            error(f"falta {s['ruta']}")
        pico, rms = cache.setdefault(s["ruta"], niveles(s["ruta"]))
        gan = (voz_pico + s["nivel_db"] - pico) if s["referencia_nivel"] == "pico" else (voz_rms + s["nivel_db"] - rms)
        largo = s["salida"] - s["entrada"]
        if largo <= 0.01:
            continue
        cad = f"[{i}:a]atrim=start={s['recorte_inicio']:.4f}:end={s['recorte_inicio'] + largo:.4f},asetpts=PTS-STARTPTS,volume={gan:.2f}dB"
        if s.get("fade_out"):
            fd = min(s["fade_out"], largo / 2)
            cad += f",afade=t=out:st={largo - fd:.4f}:d={fd:.4f}"
        cad += f",adelay={int(round(s['entrada'] * 1000))}:all=1[s{i}]"
        entradas += ["-i", s["ruta"]]; filtros.append(cad); etiquetas.append(f"[s{i}]")
        informe.append({"archivo": s["archivo"], "entrada": s["entrada"], "salida": s["salida"], "nivel_db": s["nivel_db"],
                        "referencia": s["referencia_nivel"], "ganancia_aplicada_db": round(gan, 2)})
    musica = a.musica or (tl.get("musica") or {}).get("archivo")
    voz_et = "[0:a]"
    if musica:
        mdb = a.musica_db if a.musica_db is not None else (tl.get("musica") or {}).get("nivel_db", -22)
        m_pico, m_rms = niveles(musica)
        k = len(entradas) // 2
        entradas += ["-stream_loop", "-1", "-i", musica]
        filtros.append(f"[0:a]asplit=2[vz][vk]")
        filtros.append(f"[{k}:a]aformat=channel_layouts=mono,atrim=end={tl['duracion_s']:.3f},volume={voz_rms + mdb - m_rms:.2f}dB,"
                       f"afade=t=out:st={max(0, tl['duracion_s'] - 1.0):.3f}:d=1.0[mu]")
        filtros.append("[mu][vk]sidechaincompress=threshold=0.03:ratio=6:attack=15:release=350[mud]")
        voz_et = "[vz]"; etiquetas.append("[mud]")
        if not (tl.get("musica") or {}).get("origen"):
            print("AVISO: música sin 'origen' registrado en storyboard.json: no se entrega sin derechos confirmados")
    n = 1 + len(etiquetas)
    filtros.append(f"{voz_et}{''.join(etiquetas)}amix=inputs={n}:normalize=0:duration=first:dropout_transition=0[pre]")

    with tempfile.TemporaryDirectory() as td:
        pre = Path(td) / "pre.wav"
        subprocess.run(["ffmpeg", "-y", "-v", "error", *entradas, "-filter_complex", ";".join(filtros), "-map", "[pre]",
                        "-ar", "48000", "-c:a", "pcm_f32le", str(pre)], check=True)
        if voz_silencio:  # sin voz real no tiene sentido medir sonoridad: copia con pico a −3 dB
            pk, _ = niveles(pre)
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(pre), "-af", f"volume={-3 - pk:.2f}dB", "-ac", "2", "-ar", "48000",
                            "-c:a", "pcm_s16le", str(salida)], check=True)
        else:
            masterizar(pre, salida, a)
    terminar(salida, a, voz_pico, voz_rms, informe, musica, voz_silencio)


def masterizar(pre, salida, a):
    # loudnorm en dos pasadas
    err = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(pre), "-af",
                          f"loudnorm=I={a.lufs}:TP={a.tp}:LRA=11:print_format=json", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    m = json.loads(err[err.rfind("{"):err.rfind("}") + 1])
    ln = (f"loudnorm=I={a.lufs}:TP={a.tp}:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
          f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
    tmp = Path(pre).with_name("ln.wav")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(pre), "-af", ln + ",aresample=48000", "-ar", "48000",
                    "-c:a", "pcm_f32le", str(tmp)], check=True)
    # loudnorm puede quedarse corto (modo dinámico o silencios largos): corrección final de ganancia + limitador de pico
    dif = a.lufs - medir_r128(tmp)["lufs_integrados"]
    lim = 10 ** ((a.tp - 0.3) / 20)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(tmp), "-af",
                    f"volume={dif:.2f}dB,alimiter=limit={lim:.4f}:attack=2:release=60:level=disabled,aresample=48000",
                    "-ac", "2", "-ar", "48000", "-c:a", "pcm_s16le", str(salida)], check=True)


def terminar(salida, a, voz_pico, voz_rms, informe, musica, previa):
    base = salida.with_suffix("")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(salida), "-ac", "1", f"{base}_mono.wav"], check=True)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(salida), "-ac", "1", "-af", "highpass=f=300,lowpass=f=3400",
                    f"{base}_telefono.wav"], check=True)
    medida = medir_r128(salida); mono = medir_r128(f"{base}_mono.wav")
    ok = (not previa) and abs(medida["lufs_integrados"] - a.lufs) <= 1.0 and medida["pico_real_dbtp"] <= -1.0
    escribir_json(f"{base}_informe.json", {"mezcla": medida, "mono": mono, "voz_pico_db": voz_pico, "voz_rms_db": voz_rms,
                                            "objetivo": {"lufs": a.lufs, "tp_max": -1.0}, "cumple": ok, "efectos": informe,
                                            "musica": musica, "vista_previa_sin_voz": bool(previa)})
    print(f"{salida}: {medida['lufs_integrados']} LUFS · LRA {medida['lra_lu']} LU · pico real {medida['pico_real_dbtp']} dBTP · "
          f"mono {mono['lufs_integrados']} LUFS · {len(informe)} efectos · {'VISTA PREVIA (sin voz real)' if previa else 'CUMPLE' if ok else 'NO CUMPLE'}")


if __name__ == "__main__":
    main()
