#!/usr/bin/env node
// Captura cuadro a cuadro render(t) y exporta el MP4 9:16 con la mezcla.
//   node render.mjs --html render.html --timeline build_A/timeline.json --audio build_A/mezcla.wav --salida video_final_9x16_A.mp4
//        [--crf 20] [--maxrate 6M] (tope de bitrate: el grano por cuadro dispara el peso)
//        [--frasco producto/frasco_recortado.png] [--fps 30] [--desde 0 --hasta 99] [--portada 1.9]
//   Vista previa sin exportar: --cuadros 0.5,3.14,8.56  → guarda <salida sin .mp4>_t<seg>.jpg (no hace falta --audio)
// Requiere Playwright (preinstalado en el entorno) y ffmpeg. El render es determinista: la imagen en t depende solo de t.
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright'); // require: respeta NODE_PATH / instalación global
import { readFileSync, mkdirSync, rmSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { resolve, dirname, join, extname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') ? [...a, [x.slice(2), all[i + 1]]] : a), []));
for (const k of ['html', 'timeline', 'salida', ...(args.cuadros ? [] : ['audio'])]) if (!args[k]) { console.error(`falta --${k}`); process.exit(1); }
const SKILL = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const tl = JSON.parse(readFileSync(args.timeline, 'utf8'));
const fps = Number(args.fps || tl.fps || 30);
const t0 = Number(args.desde || 0), t1 = Math.min(Number(args.hasta || 1e9), tl.duracion_s);
let frasco = null;
const fr = args.frasco || (tl.shared?.frasco?.imagen);
if (fr && existsSync(fr)) frasco = `data:image/${extname(fr).slice(1).replace('jpg', 'jpeg')};base64,` + readFileSync(fr).toString('base64');
else console.log(`AVISO: sin imagen real del frasco (${fr || 'no indicada'}): se dibuja el marcador "FOTO REAL PENDIENTE"`);
const fuentes = ['DMSans-400', 'DMSans-700', 'DMSans-800', 'BigShouldersDisplay-900'].map(f => {
  const [fam, w] = f.split('-'); const name = fam === 'DMSans' ? 'DM Sans' : 'Big Shoulders Display';
  return `@font-face{font-family:'${name}';font-weight:${w};src:url('${pathToFileURL(join(SKILL, 'recursos/tipografias', f + '.ttf'))}')}`; }).join('');

const tmp = resolve(dirname(args.salida), '_cuadros_' + Date.now()); mkdirSync(tmp, { recursive: true });
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
await page.goto(pathToFileURL(resolve(args.html)).href);
await page.addStyleTag({ content: fuentes });
await page.evaluate(([tl, fr]) => { window.TL = tl; window.FRASCO = fr; }, [tl, frasco]);
await page.evaluate(() => document.fonts.ready);
if (args.cuadros) {
  for (const t of args.cuadros.split(',').map(Number)) {
    await page.evaluate(t => window.render(t), t);
    await page.screenshot({ path: args.salida.replace(/\.mp4$/, '') + `_t${t.toFixed(2)}.jpg`, type: 'jpeg', quality: 90 });
  }
  await browser.close(); rmSync(tmp, { recursive: true, force: true }); console.log('vista previa lista'); process.exit(0);
}
const n0 = Math.round(t0 * fps), n1 = Math.round(t1 * fps);
for (let i = n0; i < n1; i++) {
  await page.evaluate(t => window.render(t), i / fps);
  await page.screenshot({ path: join(tmp, `f_${String(i - n0).padStart(5, '0')}.jpg`), type: 'jpeg', quality: 92 });
  if ((i - n0) % 150 === 0) console.log(`cuadro ${i - n0}/${n1 - n0}`);
}
await browser.close();
execFileSync('ffmpeg', ['-y', '-v', 'error', '-framerate', String(fps), '-i', join(tmp, 'f_%05d.jpg'), '-ss', String(t0), '-t', String(t1 - t0), '-i', args.audio,
  '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', String(args.crf || 20), '-maxrate', args.maxrate || '6M', '-bufsize', '12M', '-preset', 'veryfast', '-r', String(fps), '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
  '-movflags', '+faststart', '-shortest', args.salida], { stdio: 'inherit' });
if (args.portada) execFileSync('ffmpeg', ['-y', '-v', 'error', '-ss', String(args.portada), '-i', args.salida, '-frames:v', '1', '-q:v', '2',
  args.salida.replace(/video_final_9x16_?/, 'portada_').replace(/\.mp4$/, '.jpg')]);
rmSync(tmp, { recursive: true, force: true });
console.log(`${args.salida} · ${(n1 - n0)} cuadros a ${fps} fps`);
