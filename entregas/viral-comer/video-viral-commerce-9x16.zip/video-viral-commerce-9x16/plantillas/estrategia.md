# Estrategia · <producto> · <mes>

## 1. Nicho y ejemplos
| # | Enlace | Qué tomamos (estructura / ritmo / metáfora) | Qué NO tomamos |
|---|---|---|---|
| 1 | | | dibujos, personajes, marca |

## 2. Pilares (3–5)
| Pilar | Qué explica | Evidencia disponible | Producto entra como |
|---|---|---|---|
| Mecanismo del dolor | | | |
| Mito vs. realidad | | | |
| Cómo reconocer el original | etiqueta, frasco de aluminio, precinto | foto de etiqueta | prueba visible |
| Rutina / uso | | ficha | |
| Objeción (precio, confianza) | | oferta vigente | |

## 3. Banco de 30 ganchos (≤ 12 palabras)
| # | Pilar | Tipo (pregunta · dolor · cifra · mira esto · comparación) | Gancho | Fuente si hay cifra | Usado en |
|---|---|---|---|---|---|
| 1 | | | | | |
<!-- …hasta 30 -->

## 4. Métricas semanales (3)
| Métrica | Definición exacta (numerador / denominador) | Ventana | Meta |
|---|---|---|---|
| Hook rate 3 s | reproducciones 3 s / impresiones | 7 días | |
| Retención 50 % | reproducciones al 50 % / reproducciones 3 s | 7 días | |
| Costo por conversación | gasto / conversaciones iniciadas | 7 días | |

## 5. Aprendizajes (apertura A vs. B)
| Fecha | Video | Ganó | Métrica y denominador | Ventana | Nota (sin atribuir ventas a una sola vista) |
|---|---|---|---|---|---|
