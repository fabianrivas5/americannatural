# Investigación · <producto> · <video>

**Idea que el espectador podrá contar al terminar (1 frase):**

**Cadena causa → consecuencia (lo que la metáfora debe mostrar):**
1. 
2. 
3. 

## Fuentes
| Id | Afirmación exacta | Fuente primaria (autor/organismo, título, fecha, enlace o archivo) | 2.ª fuente (si es cifra sorprendente) | Contexto (de cuántos, dónde, cuándo) | Evidencia en contra |
|---|---|---|---|---|---|
| F1 | | | | | |

## Producto (solo materiales del encargo)
| Dato | Valor | Sustento (foto de etiqueta / ficha / mensaje de Gabo + fecha) |
|---|---|---|
| Nombre exacto | | |
| Contenido / ingredientes | | |
| Cantidad (cápsulas, g, ml) | | |
| Precio y combos (país) | | |
| Envío, plazo, pago contra entrega | | |
| Señales de original (frasco, tapa, precinto) | | |

## Descartado
| Qué | Por qué |
|---|---|
