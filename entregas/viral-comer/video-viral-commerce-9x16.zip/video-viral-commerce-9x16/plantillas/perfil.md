# Perfil · American Natural (video viral commerce)

> Solo preferencias que Gabo dijo explícitamente. Fecha de cada cambio. Los supuestos de una pieza van en su `guion.md`.

| Campo | Valor | Fecha / fuente |
|---|---|---|
| Objetivo de la cuenta | ventas COD por WhatsApp | |
| Público principal | | |
| País · idioma · moneda | Ecuador · español (ecuatoriano) · USD | |
| Tono | dolor fuerte, directo, persuasivo, natural | |
| CTA / cierre habitual | "Pídelo contra entrega, pagas al recibir" (confirmar por país) | |
| Ritmo semanal | __ videos/semana · días/horas | |
| Voz | proveedor · id · velocidad · (edge-tts es-EC-LuisNeural +0 % por defecto) | |
| Efectos | sí, discretos, del banco de la skill | |
| Música | sin música salvo pista con derechos aportada | |
| Estilo visual por defecto | A (noche + horizonte naranja) / B (azul marino diagrama) | |
| Subtítulos | estilo A/B · fuente · color de acento | |
| Palabras prohibidas | "suplemento alimenticio", "no es un medicamento" (salvo obligación legal) | regla de la skill |
| Métricas que mira | hook rate 3 s · retención 50 % · costo por conversación | |

## Correcciones repetidas (candidatas a preferencia)
- 
