# Notas de producción · <video>

## Cambios pedidos por Gabo
| Fecha | Pedido (sus palabras) | Qué se cambió (archivo / escena / segundo) | ¿Guardar en perfil? |
|---|---|---|---|

## Correcciones de revisión
| Segundo | Defecto | Corrección | Re-revisado |
|---|---|---|---|

## Entrega
- [ ] video_final_9x16_A.mp4 · video_final_9x16_B.mp4
- [ ] portada_A.jpg · portada_B.jpg (prometen lo que se ve)
- [ ] copy_publicacion.txt (sin link)
- [ ] guion.md · storyboard.json · timeline.json · planos.md · hoja_sonido.md · subtitulos.srt · revision.md
- [ ] Publicación: decide Gabo (no se sube nada)

## Aprendizaje para la próxima pieza
- 
