# 01 · Perfil, estrategia y calendario

## Perfil (se hace una vez, se reutiliza)
Archivo del proyecto: `perfil_american_natural.md` (copiar `plantillas/perfil.md`). Si existe, léelo antes de la entrevista y **no repitas** las preguntas que ya responde; di cuáles diste por respondidas.

Guarda solo lo que Gabo dijo explícitamente: objetivo de la cuenta, público, país e idioma, tono, frase de cierre/CTA habitual, ritmo semanal, voz elegida (proveedor, id, velocidad), preferencia de efectos (sí/no/discretos), música (con o sin derechos), estilo visual por defecto.
Separa siempre:
- **Preferencias fijas** (perfil) → valen para todas las piezas.
- **Supuestos de la pieza** (en `guion.md` de cada video) → no se copian al perfil sin que Gabo lo confirme.

Si Gabo corrige algo dos veces en piezas distintas (ej. "voz más lenta"), propón guardarlo en el perfil.

## Estrategia (solo si piden plan, calendario o "qué videos hago")
Plantilla: `plantillas/estrategia.md`. Contenido:
1. Nicho y ejemplos: 3–6 referencias del nicho con enlace y qué se toma de cada una (estructura, ritmo, metáfora; nunca dibujos ni marca).
2. **3 a 5 pilares** recurrentes por producto (ej. mecanismo del dolor, mito vs. realidad, cómo reconocer el original, rutina, objeción de precio).
3. **Banco de 30 ganchos** ≤ 12 palabras, 6 por pilar aprox., cada uno con tipo (pregunta que rompe creencia, dolor directo, cifra, "mira esto", comparación). Los ganchos con cifra llevan la fuente o `PENDIENTE`.
4. **3 métricas semanales** elegidas según el objetivo. Ventas COD: retención a 3 s (hook rate), retención 50 %, costo por conversación/pedido. Alcance: vistas 3 s, compartidos, seguidores. Siempre con mismo objetivo, ventana y denominador al comparar.
5. Aprendizajes: qué apertura ganó y con qué denominador. Nunca atribuir una venta a una sola vista ni a un solo video.

## Calendario de 4 semanas
1. Llenar `plantillas/calendario.csv` (fecha, hora, producto, pilar, gancho_A, gancho_B, objetivo, estado).
2. Generar vistas:
```bash
python3 <skill>/scripts/calendario.py --csv calendario.csv --salida calendario --zona America/Guayaquil
```
Crea `calendario.ics` (importable en Google Calendar/Outlook) y `calendario.html` (vista por semanas).
3. Cuando Gabo diga que una pieza se publicó, cambia `estado` a `publicado` y vuelve a correr el script. Publicar lo hace Gabo, nunca la skill.

Un encargo puede venir de: una fila del calendario, un tema de Gabo o un guion suyo. En el tercer caso se conserva su texto y solo se marcan dudas de verificación y la propuesta de apertura B.
