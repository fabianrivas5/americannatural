# 03 · Guion y dos aperturas

## Guion
- Una frase = un concepto = una escena (6–12 palabras). ~2,3–2,8 palabras/s.
- Para cada tramo deja escrita la **idea**, la **frase** y la **evidencia** (la fila de la tabla de verificación que la respalda).
- Coloca una **pregunta puente** justo después de una evidencia visible ("¿y por qué pasa esto?"); la escena siguiente la responde con un objeto, gesto o detalle identificable.
- El cierre vuelve a la situación del gancho (misma persona/objeto) y pide **una sola acción**.
- Oferta: "Paga al recibir" / "pagas cuando lo recibes" solo si la oferta COD del país está confirmada.

## Dos aperturas (A y B), siempre
Se escriben y producen dos versiones del primer tramo (0–3 s) **con el mismo cuerpo**:
- Mismo cuerpo de voz (el audio del cuerpo se genera una vez y se reutiliza), mismos planos del cuerpo, mismo CTA.
- Duración de las aperturas: diferencia ≤ 0,3 s para que la comparación sea justa. Si no se consigue, se reporta.
- Tipos que conviene contrastar (elige dos distintos):
  1. Pregunta que rompe una creencia ("¿Comes poco y aun así…?").
  2. Dolor directo en segunda persona.
  3. Cifra o comparación visible (solo con fuente).
  4. "Mira esto" + objeto/detalle que se resuelve en pantalla (macro de etiqueta, gesto).
- El primer fotograma de cada apertura ya muestra el tema (nada de logo ni intro). Escribe qué se ve en el **fotograma 0** de cada una.
- La portada de cada variante repite el sujeto y la palabra resaltada de su apertura (lo que promete la portada debe verse en el video).

Formato de entrega:

| Apertura | Tipo | Voz (≤ 12 palabras) | Fotograma 0 | 0–1 s | 1–3 s | Subtítulo | Sonido | Portada |
|---|---|---|---|---|---|---|---|---|

## Cómo comparar aperturas después
Solo si Gabo trae métricas: mismo objetivo de campaña, misma ventana, mismo denominador (ej. reproducciones de 3 s / impresiones). Guardar el aprendizaje en `estrategia.md` sin atribuir ventas a una sola vista.

## Cambios en la narración
Si se cambia una palabra de la voz (o la apertura), **no se editan tiempos a mano**: se regenera la voz del segmento, se reensambla la variante y se vuelve a correr `plan_audio.py`. Subtítulos y efectos anclados a palabras se mueven solos; los anclados a una palabra que ya no existe dan error y hay que reasignarlos.
