# 02 · Investigación y verificación del guion

Tres revisiones, cada una con un trabajo distinto. Se pueden hacer en secuencia por el mismo agente, pero sin mezclar sus preguntas.

## 1. Investigación (antes del guion)
Plantilla: `plantillas/investigacion.md`.
- **Idea que el espectador podrá contar al terminar** (una frase). Si no cabe en una frase, el video tiene dos temas.
- Cadena causa → consecuencia del dolor (lo que la metáfora visual tiene que mostrar).
- Por cada afirmación: fuente primaria, autor/organismo, fecha, cita o dato exacto. Una cifra sorprendente necesita **dos fuentes**. Pon la cifra en contexto (¿de cuántos?, ¿dónde?, ¿cuándo?).
- Busca activamente evidencia que **contradiga** la afirmación y anótala.
- Registra lo descartado y por qué.
- **Producto (commerce):** cada dato del producto sale de la etiqueta (foto legible), la ficha del fabricante o la prueba que Gabo entregue. Guarda el nombre del archivo o el fotograma que lo sustenta. Promoción (precio, combo, envío, plazo) solo con confirmación vigente de Gabo para ese país.

## 2. Verificación del guion (después del borrador, antes del "ok")
Escena por escena, tabla en `guion.md`:

| Escena | Afirmación (voz o pantalla) | Tipo | Fuente | Veredicto | Motivo / corrección |
|---|---|---|---|---|---|

- Tipo: mecanismo, cifra, producto-contenido, producto-cantidad, precio, país, entrega/pago, testimonio.
- Veredicto: **se sostiene** · **requiere matiz** (reescribe la frase y muestra la nueva) · **sin evidencia** (sale del guion o queda `PENDIENTE` y no se renderiza con esa frase).
- En pieza comercial se comprueban **por separado**: contenido (ingredientes), cantidad (cápsulas, ml, g), precio, país, condiciones de entrega y pago. Un acierto en uno no valida los otros.
- Respeta el ángulo de Gabo: la verificación cambia la formulación, no el ángulo. Si una promesa no se puede sostener, conserva el ángulo y reformula sin resultado garantizado (ej. "vientre plano en 10 días" → "¿buscas un vientre más plano? antes de comprar otra cosa, mira esto").
- Si falta voz o una cifra, la pieza puede seguir como storyboard con el campo `PENDIENTE` y los tiempos marcados como previstos.

## 3. Revisión visual
Va después del render: `referencias/07_revision_exportacion.md`.
