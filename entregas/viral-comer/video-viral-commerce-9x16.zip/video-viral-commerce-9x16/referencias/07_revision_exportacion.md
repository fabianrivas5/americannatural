# 07 · Revisión y exportación

## Revisión automática + visual
```bash
python3 <skill>/scripts/revisar.py --video video_final_9x16_A.mp4 --timeline build_A/timeline.json --salida build_A/revision
```
Produce `revision/revision.md` con:
1. **Técnica** (automático): 1080×1920, 30 fps, H.264 yuv420p, AAC, faststart, duración vídeo = duración audio de la voz (±0,1 s).
2. **Tramos estáticos** (automático, `freezedetect`): cualquier tramo > 2 s sin cambio visual.
3. **Audio** (automático, EBU R128): LUFS integrados, LRA, pico real; aviso fuera de −14 ±1 LUFS o > −1 dBTP.
4. **Fotogramas en cada palabra clave** con la zona segura dibujada (`revision/fotogramas/`, y `hoja_contacto.jpg`): mira cada uno.

5. **Sincronía de efectos medida** (`scripts/medir_sincronia.py video.mp4 timeline.json`): dónde cae de verdad el pico de cada efecto en el audio exportado; tolerancia 1 fotograma (33 ms). Detecta pistas cuyo pico se desplaza con el AAC.

Qué mirar en cada fotograma (contra lo que se oye en ese segundo):
- La imagen muestra la palabra clave **en ese instante** (desfase ≤ 80 ms ≈ 2 fotogramas).
- Tamaño del sujeto: se entiende en un móvil sin ampliar.
- Saltos de continuidad (frasco, color, luz, personaje).
- Elementos cortados por el borde o dentro de la franja de botones (derecha) y de descripción (abajo).
- Subtítulo legible y sin tapar el sujeto ni la etiqueta.
- Efecto: el pico cae en el gesto.

## Registro de correcciones
Cada fallo con segundo y corrección concreta, y estado tras re-revisar **solo ese tramo**:

| Segundo | Se oye | Se ve | Defecto | Corrección | Estado |
|---|---|---|---|---|---|
| 07,95 | "…atrapado" | intestino ya salió del cuadro | salida 0,3 s antes de la palabra | retrasar salida a 8,30 | corregido ✔ (re-revisado) |

Los cambios pedidos por Gabo y lo aprendido se anotan en `notas.md` (`plantillas/notas.md`): qué pidió, qué se cambió, qué se guarda en el perfil.

## Exportación (por variante)
```bash
ffmpeg -y -framerate 30 -i frames/f_%05d.png -i build_A/mezcla.wav -c:v libx264 -pix_fmt yuv420p -crf 20 -maxrate 6M -bufsize 12M -preset veryfast -r 30 -c:a aac -b:a 192k -ar 48000 -movflags +faststart -shortest video_final_9x16_A.mp4
ffmpeg -y -ss <t_portada> -i video_final_9x16_A.mp4 -frames:v 1 -q:v 2 portada_A.jpg
```
Entregables: `video_final_9x16_A.mp4`, `video_final_9x16_B.mp4`, `portada_A.jpg`, `portada_B.jpg`, `copy_publicacion.txt` (texto para acompañar, sin link, con la misma promesa del video), `guion.md`, `storyboard.json`, `timeline.json`, `planos.md`, `hoja_sonido.md`, `subtitulos.srt`, `revision.md`.
- La portada repite sujeto y palabra resaltada de su apertura y promete exactamente lo que se ve.
- Mide la exportación final (no la mezcla) con `revisar.py`: el AAC puede subir el pico.
- No se publica ni se sube nada: Gabo decide.
