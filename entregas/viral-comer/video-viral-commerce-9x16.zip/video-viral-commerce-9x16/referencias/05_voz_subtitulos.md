# 05 · Voz y subtítulos

## Voz
Se genera **después** del "ok" del guion. Por variante: `apertura_A`, `apertura_B` y `cuerpo` como segmentos separados; el cuerpo se genera **una vez** y se reutiliza en las dos variantes.

Rutas (todas dejan `<base>.wav` 48 kHz mono + `<base>.json` con tiempos por palabra):
```bash
# 1) edge-tts (por defecto, gratis). Voces: es-EC-LuisNeural, es-EC-AndreaNeural
python3 <skill>/scripts/voz.py tts --texto-archivo cuerpo.txt --voz es-EC-LuisNeural --velocidad +0% --salida voz/cuerpo
# 2) ElevenLabs u otra voz ya generada + transcripción con tiempos por palabra (Scribe, Whisper, SRT/VTT palabra a palabra)
python3 <skill>/scripts/voz.py importar --audio cuerpo.mp3 --palabras scribe_words.json --texto-archivo cuerpo.txt --salida voz/cuerpo
# 3) Sin voz todavía: tiempos PREVISTOS (2,5 palabras/s + pausas en puntuación) y silencio de esa duración
python3 <skill>/scripts/voz.py estimar --texto-archivo cuerpo.txt --pps 2.5 --salida voz/cuerpo
# Ensamblar variante (apertura + cuerpo) con la pausa entre ambos
python3 <skill>/scripts/voz.py ensamblar --segmentos voz/apertura_A voz/cuerpo --pausa 0.25 --salida voz/variante_A
```
- `edge-tts` necesita salida a `speech.platform.bing.com`; si la red pasa por proxy usa `--proxy "$HTTPS_PROXY"`. Si está bloqueado, usa la ruta 2 o la 3 y dilo.
- Con ElevenLabs: probar 2–3 voces con **la misma frase** (la del gancho) antes de narrar todo. Avisar del coste antes de una 3.ª toma pagada. Guardar la voz elegida en el perfil.
- Medir siempre con `ffprobe` la duración real. La duración del video sale del audio.
- `"previsto": true` en el JSON marca tiempos estimados: todo lo que dependa de ellos (planos, subtítulos, efectos) se rotula **PREVISTO** en las tablas hasta tener la voz real.
- Recorte: deja ≤ 0,15 s de silencio al inicio de la apertura (el gancho debe sonar desde el fotograma 0–5) y ≤ 0,5 s al final.

## Subtítulos
Los genera `plan_audio.py` a partir de **la frase del guion** (texto) + **los tiempos de la voz real** (alineados por palabra; tolera números escritos en letra o cifra y palabras que la voz omita):
- Bloques de 2–5 palabras, corte en puntuación, máx. 1,6 s por bloque, mín. ~0,5 s.
- Palabra activa = la que suena; palabras de `subtitulo_resaltar` en color de acento (estilo A: caja blanca, texto negro, acento con fondo amarillo #FFD400 y texto oscuro; estilo B: gris con activa en blanco).
- Fuente: Poppins/Inter Bold; alternativa incluida `recursos/tipografias/DMSans-800.ttf` (texto) y `BigShouldersDisplay-900.ttf` (cifras y rótulos grandes), licencia OFL en la misma carpeta.
- Posición por defecto: centro-bajo dentro de la zona segura (y ≈ 1250–1500). Pasa a la franja superior cuando la acción principal o la etiqueta está abajo (`subtitulo_posicion: "arriba"` en la escena).
- Salidas: `subtitulos.json` (para el render, con palabras y tiempos) y `subtitulos.srt` (para subir aparte si se quiere).

## Si cambia la narración
1. Edita la frase en `storyboard.json` (y en el .txt del segmento).
2. Regenera solo ese segmento de voz → `ensamblar` → `plan_audio.py`.
3. Revisa la sección "Avisos" de la salida: un ancla `{"palabra": …}` que ya no existe en la frase **falla** a propósito; reasígnala.
4. Re-render solo de las escenas cuya entrada/salida cambió (el render es determinista por `t`) y re-mezcla.
