# 06 · Diseño sonoro y mezcla

## El banco
- `recursos/sonidos/` — 142 OGG Vorbis, mono, 48 kHz, CC0 (Kenney y Freesound). Créditos por archivo: `recursos/sonidos/CREDITOS.md`. Huellas: `recursos/SHA256SUMS.txt`.
- `recursos/catalogo_sonidos.tsv` — una fila por archivo: `archivo, familia, categoría, duración_s, primer_pico_s, códec, Hz, canales, bytes, origen, licencia`. El pico es la primera muestra de mayor amplitud absoluta al decodificar (redondeado al ms).
- Buscar y consultar sin abrir el TSV:
```bash
python3 <skill>/scripts/sonidos.py buscar whoosh            # por nombre, familia o categoría
python3 <skill>/scripts/sonidos.py buscar --categoria "Golpes y énfasis" --max-dur 0.6
python3 <skill>/scripts/sonidos.py info papel-1.ogg
python3 <skill>/scripts/sonidos.py colocar papel-1.ogg --t 1.600   # → entrada 1.079 s
python3 <skill>/scripts/sonidos.py verificar                 # 142 archivos ↔ catálogo ↔ SHA-256
```
- Categorías: Materiales y objetos (35) · Golpes y énfasis (28) · Interfaz y tecnología (25) · Transición y movimiento (20) · Agua y cocina (12) · Organismo, personas y tiempo (10) · Entorno y transporte (10) · Acentos luminosos (2).

### Cuidado: el nombre no siempre es el sonido
Los nombres son familias editoriales en español; elige por el **origen** (título de la grabación original, columna `origen_segun_creditos`) y, si puedes, escuchando. Casos comprobados en los créditos:
- `caja-1/2.ogg` = **caja registradora** («Cash Register…»), no una caja de cartón. Para abrir un paquete usa `papel-*`, `tela-*` o `cremallera-*`.
- `timbre-1/2.ogg` = **timbre de bicicleta** («Bike Bell», «bicycle bell»), no timbre de puerta. Para una entrega usa `puerta-*`.
- `sube-1/2.ogg` = swooshes de D4XX procesados (misma fuente que `whoosh-1/2`), sirven como "algo que sube o se hincha".
- `tic-*`, `metal-*`, `golpe-seco-*` = Kenney «impact sounds» (golpes cortos), no un reloj: para un reloj real usa `reloj-1.ogg`.
`sonidos.py info <archivo>` muestra el origen antes de elegir.

## Regla de uso
Un efecto entra **solo si subraya una acción visible** (un gesto, un objeto que aparece, un corte). Si la escena se entiende mejor con voz sola, se escribe en `sonido_decision` ("solo voz: la frase de precio necesita claridad"). Nada de efectos encima de la palabra de precio ni del CTA salvo uno muy breve antes.

## Por escena: qué se anota (obligatorio)
```json
{"archivo": "papel-1.ogg",
 "en": {"palabra": "abres"},          // palabra o gesto que lo activa (ver anclas en 04)
 "gesto": "la mano aparta el papel",   // acción visible
 "sync": "pico",                       // "pico" (del catálogo) o segundos dentro de la pista elegidos de oído
 "nivel_db": -12,                      // relativo a la voz (ver abajo)
 "hasta": null,                        // o {"palabra": "frasco"} / {"fin_escena": true} para cortar con fundido
 "fade_out": 0.12,
 "motivo": "textura de papel real en el instante en que se retira la envoltura"}
```
`plan_audio.py` lo convierte en la **hoja de sonido** (`hoja_sonido.md` + `.tsv`):
`# | Escena | Archivo (ruta real) | Activador | Gesto | t objetivo | Sync en pista | Entrada | Salida | Nivel vs voz | Motivo | Origen`.

### Cálculo
**entrada de la pista = t objetivo − punto de sincronía de la pista.**
- Punto de sincronía por defecto = `primer_pico_s` del catálogo. Ej.: `clic-1.ogg` pico 0,017 s; marcador a 2,400 s → entrada 2,383 s. `papel-1.ogg` pico 0,521 s; gesto a 1,600 s → entrada 1,079 s.
- **Nitidez del pico** (`recursos/nitidez_pico.tsv`, `sonidos.py nitidez`): nivel de la envolvente en el pico ÷ mayor nivel fuera de ±40 ms. **≥ 1,5 = golpe claro**, sirve para sincronizar un gesto. **< 1,5** (71 de 142: texturas, barridos suaves, foley de varios golpes) = el pico depende del decodificador y del AAC final; en la prueba `cremallera-2.ogg` (0,89) cayó 128 ms antes de lo previsto tras exportar. Con esas pistas: `"sync"` de oído (p. ej. `0` para que la textura entre con la palabra) o elige otra con golpe claro. `plan_audio.py` y `sonidos.py colocar` avisan; `buscar` marca con `!`.
- Ambientes largos (bosque, lluvia, mar, calle, fuego, hervir, viento, ambiente-agua) y foley con varios golpes: el pico absoluto no representa la acción → usa `"sync": 0` (o el segundo escuchado) y define `hasta`.
- Barridos (whoosh, whoosh-largo, swish) **anticipan** el corte: ancla `{"t_escena": 0}` de la escena que entra; el pico cae en el corte. Ej. de referencia medido: barrido ~0,28 s antes de un cambio de plano grande.
- Si la entrada calculada es < 0, el script la recorta a 0 y avisa (el pico ya no cae en el gesto: cambia de pista o de ancla).
- Salida = entrada + duración, o el instante `hasta` con `fade_out`. Ninguna pista termina de golpe: si se recorta, fundido ≥ 80 ms.

### Nivel relativo a la voz (`nivel_db`)
- Efectos cortos (< 4 s): **pico del efecto respecto al pico de la voz**. Guía: clic/tic/pop −14 a −10 dB · whoosh −12 a −8 · golpe/impacto −10 a −6 (solo en énfasis) · materiales/foley −14 a −10.
- Ambientes (≥ 4 s): **RMS del ambiente respecto al RMS de la voz**, −24 a −18 dB.
- Música (solo pista con derechos y `origen` registrado): −22 dB RMS bajo la voz, con ducking (sidechain) cuando habla.
- Máximo 2 efectos en la misma ventana de 0,5 s; el script avisa si hay más.

## Mezcla y masterizado
```bash
python3 <skill>/scripts/mezclar.py --timeline build_A/timeline.json --voz voz/variante_A.wav --salida build_A/mezcla.wav
```
- Mide voz y cada efecto (`volumedetect`), aplica la ganancia para el `nivel_db`, coloca con `adelay`, recorta/funde con `atrim`/`afade`, suma sin normalizar, y masteriza con `loudnorm` a **−14 LUFS integrados, pico real ≤ −1 dBTP** (dos pasadas).
- Deja también `mezcla_mono.wav` y `mezcla_telefono.wav` (300–3.400 Hz) para escuchar inteligibilidad y el CTA como en un altavoz de teléfono, y `mezcla_informe.json` con LUFS/LRA/dBTP medidos.
- Referencia medida (ejemplo de muestra, no meta obligatoria): mezcla final −14,3 LUFS, LRA 2,1 LU, −1,1 dBTP; voz sola −20 LUFS.
- Escucha voz + efectos juntos antes de exportar: palabra clave y CTA claras, sin saturación, sin desfase, sin colas cortadas.

## Sonidos propios
Se aceptan WAV, MP3, OGG, M4A o FLAC aportados por Gabo: ponlos en `./video_<producto>/sonidos_propios/`, añade una fila en `sonidos_propios.tsv` con el mismo formato del catálogo (incluye `origen` y `licencia`) y pásalo a `plan_audio.py --catalogo-extra`. Sin origen registrado no se usan.
