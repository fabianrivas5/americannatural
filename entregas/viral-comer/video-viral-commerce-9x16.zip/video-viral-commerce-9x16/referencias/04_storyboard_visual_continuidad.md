# 04 · Storyboard por segundos, dirección visual y continuidad

Una escena está lista para producirse cuando sabes **qué** aparece, **en qué instante** (palabra o segundo) y **qué evidencia** necesita el espectador para entenderlo.

## storyboard.json
Plantilla comentada: `plantillas/storyboard.json`. Estructura:
- `shared`: lo que se repite entre escenas (paleta, luz, grano, frasco, tipografía, estilo de subtítulo). El render lo importa una vez: **no se redefine por escena**.
- `aperturas.A` y `aperturas.B`: escenas del gancho de cada variante.
- `cuerpo`: escenas comunes a las dos variantes.
- `musica` (opcional): solo con pista con derechos y origen.

Campos por escena (todos obligatorios salvo los marcados):
| Campo | Qué es |
|---|---|
| `id` | A1, B1, C1, C2… |
| `funcion` | gancho · mecanismo · prueba · producto · cta · puente |
| `voz` | frase exacta (fuente de verdad de subtítulos) |
| `palabra_clave` | palabra decisiva: en ese instante la imagen debe mostrar lo que se dice |
| `accion_visible` | qué pasa en pantalla, verbo + objeto ("la barriga se infla") |
| `encuadre` | plano y movimiento ("plano medio, zoom 1.00→1.06, eje centrado en y=900") |
| `transicion_entrada` | `corte` · `continuidad` (el objeto sigue en pantalla y se transforma) · `fundido` |
| `subtitulo_resaltar` | palabras que van en color de acento |
| `eventos` | micro-eventos cada 1–2 s, anclados: `{"en": {"palabra": "gases"}, "que": "burbujas suben"}` |
| `sonidos` | efectos del banco (ver `06_diseno_sonoro_mezcla.md`) |
| `sonido_decision` | (opcional) si la escena va con voz sola, escribe por qué |
| `evidencia` | id de la fila de verificación (V1…) o `—` si no hay afirmación |

Anclas válidas para `eventos[].en` y `sonidos[].en`:
- `{"palabra": "inflada"}` (+ `"ocurrencia": 2`, `"punto": "fin"` opcionales) → instante de esa palabra dentro de la escena.
- `{"t_escena": 0.4}` → segundos desde el inicio de la escena (puede ser negativo: −0,25 = antes del corte).
- `{"inicio_escena": true}` / `{"fin_escena": true}`.
- `{"t": 12.3}` → segundo absoluto (evitar: no se mueve si cambia la voz).
- Cualquier ancla admite `"desfase": 0.12` (segundos, + o −): úsalo cuando el gesto visible ocurre un poco después de que arranca su animación (un frasco que cae y rebota toca el suelo ~0,12 s después). El efecto se ancla a la misma palabra + desfase, para que su pico caiga en el contacto y no al inicio del movimiento.

`scripts/plan_audio.py` convierte todo esto en `timeline.json` con segundos reales; el render lee `timeline.json`, nunca tiempos escritos a mano.

## Tabla por segundos (lo que se entrega a Gabo)
`plan_audio.py` genera `planos.md`: `Escena | Entrada | Salida | Voz | Palabra clave (s) | Acción visible | Encuadre | Transición | Subtítulo | Sonido | Evidencia`, y debajo de cada escena sus micro-eventos con segundo.

## Dirección visual: cuándo usar cada recurso
Elige un recurso solo si ayuda a **ver** lo que explica el guion:
| Necesitas mostrar | Recurso |
|---|---|
| Tamaño/escala (algo diminuto, mucha cantidad) | cambio de escala + medida dibujada, comparación con objeto cotidiano |
| Proceso interno | corte transversal, recorrido con flecha animada, partículas que avanzan |
| Cantidad o tiempo | contador animado (cifra en Big Shoulders Display), barra que se llena, reloj |
| Antes / después | pantalla dividida, mismo encuadre con cambio de color |
| Volumen, gases, líquidos | burbujas, líquido que sube, esferas con sombra de contacto |
| Ruptura de creencia | objeto que se rompe/tacha, error rojo → acierto verde |
| Producto | frasco real recortado, luz de borde, macro a la línea de etiqueta que se nombra |
| Lugar / envío | mapa de `recursos/mapa/tierra.json` (Natural Earth, dominio público) |

Texturas: grano sutil, sombras planas de contacto, fondo con profundidad (2–3 planos con parallax), desenfoque del plano trasero cuando entra el producto. Movimiento escalonado (stagger 60–120 ms) en etiquetas y listas.

## Continuidad
- Protagonista (personaje/órgano/avatar): mismo trazo, proporciones, paleta y dirección de luz en todas las escenas. Define su función de dibujo en `shared` y reutilízala.
- **Frasco real**: una sola imagen de referencia recortada (`shared.frasco.imagen`) para etiqueta, tapa, escala, proporciones y color. Prohibido redibujar la etiqueta o cambiar su color. En macros, recorta de la misma foto (no generes otra etiqueta).
- Paso entre escenas: si el objeto sigue en pantalla usa `continuidad` (se transforma); si cambia el lugar usa `corte` precedido de whoosh (ver `06`); `fundido` solo para salto de tiempo.
- El subtítulo nunca tapa el sujeto ni la línea de etiqueta que se está leyendo: si chocan, sube el subtítulo a la franja superior (y=180–420) para esa escena (`subtitulo_posicion: "arriba"`).
- La portada de cada variante usa el mismo sujeto, encuadre y palabra resaltada de su apertura.

## Render
Base: `plantillas/render_base.html` → copiar a `./video_<producto>/render.html`. `render(t)` lee `timeline.json`: escena activa = la que contiene `t`; progreso local = (t − entrada)/(salida − entrada); los eventos se disparan en `eventos[].t` (en el dibujo llegan como `ev[i]`, en el mismo orden del storyboard) con easing; subtítulo activo = bloque que contiene `t`, palabra activa = la que suena.
- Dibujos incluidos por `visual.tipo`: `persona` (plato, calendario, celular), `intestino` (fases lento/gases/pregunta: corte transversal con recorrido), `dos_cosas` (pantalla dividida), `frasco`, `ingredientes` (`visual.items`), `frasco_macro` (contador + macro), `entrega` (puerta, botón, rótulo COD). Añade tipos nuevos en `DIBUJOS` sin tocar la capa común.
- Frasco: `scripts/render.mjs --frasco producto/frasco_recortado.png` (o `shared.frasco.imagen`). Sin foto, dibuja un marcador rotulado **FOTO REAL PENDIENTE**: ese video no se entrega como final.
- Fuentes: el script inyecta DM Sans y Big Shoulders Display desde `recursos/tipografias/`.
- Vista previa: `node scripts/render.mjs … --cuadros 3.14,8.56` guarda fotogramas sueltos en esos segundos (sin exportar). Úsala en cada palabra clave antes del render completo: es donde aparecen choques de subtítulo, cortes por zona segura y textos que se salen.
- Render completo: ~0,25 s por cuadro (≈5 min para 40 s). Captura JPEG por cuadro → `ffmpeg` H.264 yuv420p + AAC + faststart, y `--portada <t>` saca `portada_<variante>.jpg`.
